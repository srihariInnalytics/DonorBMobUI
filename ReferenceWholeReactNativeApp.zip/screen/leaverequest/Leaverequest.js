import React, { useState, useEffect } from "react";
import { View, Dimensions, Text, FlatList, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import { MaterialIcons } from "@expo/vector-icons";
import { postToAPI, getFromAPI, putToAPI } from '../../apicall/apicall'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAPIFormat } from '../../apicall/apifFromats'
import { useAuth } from '../../auth/AuthContext'
import { formatTOddmmyy, formatDateTimeFromApiToUITimeOnly, DateTimePickerToApiFormat, getCurrDateTime, mergeDateTimeforDatePicker } from '../../shared/sharedFunctions'
import Loader from '../../component/loader/Loader'
import Toast from "react-native-toast-message";
import DropdownComponent from '../../component/dropdown2/DropDown';

const LeaveRequestForm = () => {
  const { width, height } = Dimensions.get('window');
  const [Load, setLoad] = useState(false)
  const [FromTimeDateAPI, setFromTimeDateAPI] = useState(DateTimePickerToApiFormat(new Date()));
  const [ToTimeDateAPI, setToTimeDateAPI] = useState(DateTimePickerToApiFormat(new Date()));
  const [date1, setDate1] = useState(new Date()); // for leave date
  const [date2, setDate2] = useState(new Date()); // for leave date
  const [showFromTimePicker, setShowFromTimePicker] = useState(false);
  const [showToTimePicker, setShowToTimePicker] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const { user } = useAuth();
  const [MainData, setMainData] = useState([])
  const [Error, setError] = useState(false);
  const [Data, setData] = useState(
    {
      "uid": 0,
      "employee_UID": user.login.employee_UID,
      "roll_UID": user.login.app_RollUID,
      "fromDate": "",
      "toDate": "",
      "remark": "",
      "status": 1,
      "createdDate": "",
      "modifiedBy": user.login.employee_UID,
      "modifiedDate": "",
      "leaveFlag": 0, //leave session
      "timeFlag": 0,
      "requestType": 1 //leavetype
    }
  )
  const [LeaveTypeDD, setLeaveTypeDD] = useState([
    { Description: "HalfDay", UID: 1 },
    { Description: "FullDay", UID: 2 }
  ]);
  const [LeaveType, setLeaveType] = useState(null)
  const [LeaveSessionDD, setLeaveSessionDD] = useState([
    { Description: "Afternoon", UID: 2 },
    { Description: "Forenoon", UID: 1 }
  ]);
  const [LeaveSession, setLeaveSession] = useState(null)

  const StatusColor = {
    1: '#FFD700',   // Yellow for Pending
    2: '#28a745',   // Green for Approved
    4: '#FF0000',     // Bright Red for Cancelled
  };

  const handleCancel = async (item) => {
    try {
      setLoad(true)
      const DataToAPI = { ...item };
      DataToAPI.status = 4;
      DataToAPI.modifiedBy = user.login.employee_UID
      const res1 = await putToAPI('/UpdateLeave', DataToAPI)
      console.log("Data To API", DataToAPI)
      console.log("Response After Deletion", res1)
    }
    catch (e) {
      console.log("EROOR", e)
    }
    finally {
      setLoad(false)
      fetchData()
    }
  };

  const fetchData = async () => {
    try {
      setLoad(true)
      // console.log("USERDATA -- 1" , user )
      const DataToAPI1 = {
        employeeId: user.login.employee_UID,
        rollId: user.login.app_RollUID
      };

      const [res1] = await Promise.all([
        getFromAPI('/Get-all-leave/employeeId?' + getAPIFormat(DataToAPI1)), //  5
      ]);
      setMainData(res1.data)
      // console.log("🔹 Data to api", DataToAPI1)
      // console.log("✅ Response 1 :", res1);
    } catch (e) {
      console.error("❌ Error from Permission Request:", e);
    } finally {
      setLoad(false)
    }
  };

  const updateField = (field, val) => {
    let updatedData = { ...Data };
    updatedData[field] = val; // ✅ Correct syntax
    setData(updatedData)
  }

  useEffect(() => {
    fetchData()
  }, [])

  const onSubmit = async () => {
    try {
      //---
      if (date1 && date2) {
        console.log("Comparing Dates:", date1, date2);

        const fromDate = new Date(date1).setHours(0, 0, 0, 0);
        const toDate = new Date(date2).setHours(0, 0, 0, 0);

        const today = new Date();
        const currentDate = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();

        // ❌ If fromDate < current date
        if (fromDate < currentDate) {
          Toast.show({
            type: "error",
            text1: "Invalid Date",
            text2: "From date cannot be earlier than today",
          });
          console.log("❌ From date is in the past.");
          return;
        }

        // ❌ If fromDate > toDate
        if (fromDate > toDate) {
          Toast.show({
            type: "error",
            text1: "Invalid Date Range",
            text2: "From date cannot be later than To date",
          });
          console.log("❌ From date is greater than To date.");
          return;
        }

        // ✅ All good
        console.log("✅ Date validations passed.");
      }


      //----
      let alteredData = { ...Data }
      //FORM validations starts ---------
      for (let [key, val] of Object.entries(alteredData)) {
        // if (key != "uid" && key != "status" && key != "modifiedBy" && key != "leaveFlag" && key != "timeFlag" && key != "requestType" && val == "" && val == 0) {
        if (key == 'remark' && (val == "" || val == 0)) {
          setError(true);
          console.log("Eoor", key)
          return;
        }
      }

      if (LeaveType == null) {
        setError(true);
        return;
      }
      if (LeaveSession == null && LeaveType == 1) {
        setError(true);
        return;
      }
      //from cannot be geater than to time


      //FORM validations ends---------

      setLoad(true)
      alteredData.createdDate = getCurrDateTime();
      alteredData.modifiedDate = getCurrDateTime();
      alteredData.fromDate = mergeDateTimeforDatePicker(date1, FromTimeDateAPI);
      alteredData.toDate = mergeDateTimeforDatePicker(date2, ToTimeDateAPI);

      alteredData.timeFlag = LeaveSession ?? 0;
      alteredData.leaveFlag = LeaveType;

      console.log("Data To API", alteredData)
      const response = await postToAPI('/RequestLeave', alteredData)
      console.log("response", response)
      // console.log("MESSAGE CODE ", response.messageCode) // SUCC001
      if (response.messageCode == "SUCC001") {
        Toast.show({
          type: "success",
          text1: "Success",
          text2: "Permission Applied Successfully",
        });
        fetchData();
        //making it to inital value starts
        setData(
          {
            "uid": 0,
            "employee_UID": user.login.employee_UID,
            "roll_UID": user.login.app_RollUID,
            "fromDate": "",
            "toDate": "",
            "remark": "",
            "status": 1,
            "createdDate": "",
            "modifiedBy": 0,
            "modifiedDate": "",
            "leaveFlag": 0,
            "timeFlag": 0,
            "requestType": 1
          }
        )
        setDate1(new Date())
        setDate2(new Date())
        setFromTimeDateAPI(DateTimePickerToApiFormat(new Date()))
        setToTimeDateAPI(DateTimePickerToApiFormat(new Date()))
        setError(false)
        setLeaveSession(null)
        setLeaveType(null)
        //making it to inital value ends
      }
      else if (response.message == "Choosed date leave already requested") {
        Toast.show({
          type: "error",
          text1: "Error",
          text2: "Choosed date leave already requested",
        });
        return;
      }
      else {
        Toast.show({
          type: "error",
          text1: "Failed",
          text2: "Some error occured, Try again",
        });
      }

      setShowAdd(false)
    } catch (e) {
      console.log("Error While Api Call", e)
    }
    finally {
      setLoad(false)
    }
  }

  const onBackClicked = () => {
    setShowAdd(false)
  }

  return (
    <View style={styles.container}>
      <Loader visible={Load} />
      {
        !showAdd && MainData.length == 0 &&
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
          <MaterialIcons name="inbox" size={Math.min(width, height) * 0.4} color="#ccc" />
          <Text style={{ marginTop: 20, fontSize: 18, color: '#888' }}>There is no data</Text>
        </View>
      }
      {!showAdd &&
        <FlatList
          data={MainData}
          keyExtractor={(item) => item.uid}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <View style={styles.row}>
                <Text style={styles.label}>From Date : </Text>
                <Text style={styles.value}>{formatTOddmmyy(item.fromDate)}</Text>
              </View>

              <View style={styles.row}>
                <Text style={styles.label}>To Date : </Text>
                <Text style={styles.value}>{formatTOddmmyy(item.toDate)}</Text>
              </View>

              <View style={styles.row}>
                <Text style={styles.label}>Leave Type : </Text>
                <Text style={styles.value}>{item.leaveFlag == 1 ? "Half Day" : "Full Day"}</Text>
              </View>

              {item.timeFlag != 0 && <View style={styles.row}>
                  <Text style={styles.label}>Leave Session:</Text>
                  <Text style={styles.value}>
                    {item.timeFlag == 1 ? "Forenoon" : "Afternoon"}
                  </Text>
                </View>
                }

              <View style={styles.row}>
                <Text style={styles.label}>Reason:</Text>
                <Text style={styles.value}>{item.remark}</Text>
              </View>

              <View style={styles.row}>
                <Text style={styles.label}>Status:</Text>
                <Text style={[styles.status, { color: StatusColor[item.status] }]}>
                  {item.status === 2 && "Approved" ||
                    item.status === 4 && "Cancelled" ||
                    item.status === 3 && "Rejected" ||
                    item.status === 1 && "Pending"}
                </Text>
              </View>

              {/* Cancel Button */}
              {item.status === 1 &&
                <TouchableOpacity style={styles.cancelButton} onPress={() => handleCancel(item)}>
                  <Text style={styles.buttonText}>Cancel</Text>
                </TouchableOpacity>}
            </View>
          )}
        />}

      {showAdd ? (
        <>
          {/* Date Picker starts */}
          <View style={{ marginBottom: 5 }}>
            <DropdownComponent
              data={LeaveTypeDD} // API response data
              setSelectdp={(e) => { setLeaveType(e); setLeaveSession(null) ; setDate2(new Date()) , setDate1(new Date()) }} // Function to update the selected value
              Selectdp={LeaveType} // The selected category value
              disabled={false}
              heading="Select Leave Type"
              label="Description" // Display field
              value="UID" // Actual value field
            />
            {Error && LeaveType == null && <Text style={styles.errorText}>Select this field</Text>}
          </View>

          {LeaveType == 1 &&
            <View style={{ marginBottom: 5 }}>
              <DropdownComponent
                data={LeaveSessionDD} // API response data
                setSelectdp={(e) => setLeaveSession(e)} // Function to update the selected value
                Selectdp={LeaveSession} // The selected category value
                disabled={false}
                heading="Select Leave Session"
                label="Description" // Display field
                value="UID" // Actual value field
              />
              {Error && LeaveSession == null && <Text style={styles.errorText}>Select this field</Text>}
            </View>
          }

          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <TouchableOpacity style={[styles.inputContainer, { flex: 1, marginRight: 8 }]} onPress={() => setShowFromTimePicker(true)}>
              <MaterialIcons name="calendar-today" size={24} color="#007bff" />
              <Text style={styles.inputText}>From:</Text>
              <Text style={styles.inputText}>{date1.toLocaleDateString()}</Text>
            </TouchableOpacity>

            {showFromTimePicker && (
              <DateTimePicker
                value={date1}
                mode="date"
                display="default"
                onChange={(event, selectedDate) => {
                  setShowFromTimePicker(false);
                  if (selectedDate) {
                    setDate1(selectedDate);
                    if (LeaveType == 1) {
                      setDate2(selectedDate);
                    }
                  }
                }}
              />
            )}

            {LeaveType != 1 &&
              <TouchableOpacity style={[styles.inputContainer, { flex: 1, marginLeft: 8 }]} onPress={() => setShowToTimePicker(true)}>
                <MaterialIcons name="calendar-today" size={24} color="#007bff" />
                <Text style={styles.inputText}>To:</Text>
                <Text style={styles.inputText}>{date2.toLocaleDateString()}</Text>
              </TouchableOpacity>}

            {showToTimePicker && (
              <DateTimePicker
                value={date2}
                mode="date"
                display="default"
                onChange={(event, selectedDate) => {
                  setShowToTimePicker(false);
                  if (selectedDate) setDate2(selectedDate);
                }}
              />
            )}
          </View>


          <View style={styles.inputContainer}>
            <MaterialIcons name="info" size={24} color="#007bff" />
            <TextInput
              style={styles.input}
              placeholder="Reason"
              value={Data.remark}
              onChangeText={(e) => {
                updateField("remark", e)
              }}
            />
          </View>
          {Error && (Data.remark == '' || Data.remark == 0) && <Text style={styles.errorText}>Enter this field</Text>}


          {/* Submit & Hide Button */}
          <TouchableOpacity style={styles.submitButton} onPress={onBackClicked}>
            <Text style={styles.submitText}>Cancel</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.backButton} onPress={onSubmit}>
            <Text style={styles.backText}>Submit</Text>
          </TouchableOpacity>
        </>
      ) : (
        <TouchableOpacity onPress={() => setShowAdd(true)} style={styles.floatingButton}>
          <MaterialIcons name="add" size={30} color="white" />
        </TouchableOpacity>
      )
      }
    </View >
  );
};

export default LeaveRequestForm;

const styles = StyleSheet.create({
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1, // ✅ Added border for consistency
    borderColor: "grey", // ✅ Dull Red Border
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },
  timeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  timeBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    flex: 1,
    justifyContent: "center",
    marginRight: 5,
    borderWidth: 1, // ✅ Added border
    borderColor: "black", // ✅ Dull Red Border
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Input Text
  },
  submitButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
  },
  showFormButton: {
    backgroundColor: "#D32F2F", // ✅ Dull Red Show Form Button
    padding: 12,
    alignItems: "center",
    borderRadius: 5,
    marginBottom: 10,
  },
  submitText: {
    color: "#D32F2F",
    fontWeight: "bold",
  },
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "#f5f5f5",
  },
  card: {
    backgroundColor: "#FFF",
    padding: 20,
    borderRadius: 10,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
    padding: 5
  },
  label: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
    color: "black",
  },
  value: {
    fontSize: 18, // Increased font size
    color: "#333",
  },
  status: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
  },
  floatingButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    width: 70, // Increased size
    height: 70,
    borderRadius: 35,
    backgroundColor: "#D32F2F",
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  cancelButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
  },
  buttonText: {
    color: "#D32F2F",  // ✅ Same color as border
    fontSize: 18,
    fontWeight: "bold",
  },
  errorText: {
    color: "red",
    fontSize: 12,
    marginTop: 5,
  },
  backText: {
    color: "#007bff",
    fontWeight: "bold",
  },
  backButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#007bff",  // ✅ Outline color
  },
});
