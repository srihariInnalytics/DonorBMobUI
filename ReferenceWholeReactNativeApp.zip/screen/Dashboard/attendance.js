import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { useAuth } from "../../auth/AuthContext";
import { getFromAPI } from "../../apicall/apicall";
import { getAPIFormat } from "../../apicall/apifFromats";
import { formatDateTimeFromApiToUITimeOnly, FromandToformat,getDay,getMonth } from "../../shared/sharedFunctions";
import { MaterialIcons } from "@expo/vector-icons";
import Loader from "../../component/loader/Loader";
import { useNavigation } from "@react-navigation/native";
import { Card } from "react-native-paper";

const Attendance = () => {
  const [loading, setLoading] = useState(true);
  const [attendanceData, setAttendanceData] = useState([]);
  const [fromDate, setFromDate] = useState(new Date());

  const { user } = useAuth();
  const navigation = useNavigation();

  const fetchData = async () => {
    setLoading(true);
    try {
      const requestData = {
        empId: user.login.employee_UID,
        date: FromandToformat(fromDate),
      };
      const response = await getFromAPI("/Dashboard/GetDashboardMonthlyAttendance?" + getAPIFormat(requestData));
      console.log("Fetched Data:", response);
      setAttendanceData(response.data || []);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const AttendanceCard = ({ item }) => (
    <Card style={[styles.card, item.attendanceStatus !== "Present"  && styles.absentCard]}>
      <View style={styles.cardRow}>
        {/* Date Container */}
        <View style={styles.dateContainer}>
          <Text style={styles.dateText}>{getDay(item.date)}</Text>
        </View>
  
        {/* Details Container */}
        <View style={styles.detailsContainer}>
          {item.attendanceStatus !== "Present" ? (
            <View style={styles.cardContent}>
            <Text style={styles.absentText}>{item.attendanceStatus === "Sunday" ? "SUNDAY" : "ABSENT"}</Text>
            <Text style={styles.timeText}>{item.attendanceStatus === "Sunday" ? "" : item.day}</Text>
            </View>
          ) : (
            <View style={styles.cardContent}>
              <View>
                <Text style={styles.officeText}>
                  {item.location} ({item.totalHours} Hrs)
                </Text>
                <Text style={styles.timeText}>
                  {formatDateTimeFromApiToUITimeOnly(item.punchInTime)} - {formatDateTimeFromApiToUITimeOnly(item.punchOutTime)}
                </Text>
                <Text style={styles.timeText}>{item.day}</Text>
              </View>
              <View>
                <Text style={styles.dailyText}>{item.attendanceType}</Text>
              </View>
            </View>
          )}
        </View>
      </View>
    </Card>
  );

  return (
    <View style={styles.container}>
      <Loader visible={loading} />
      <Text style={styles.title}>{getMonth(fromDate)} Month Attendance</Text>
      <FlatList
        data={attendanceData}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => <AttendanceCard item={item} />}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

export default Attendance;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: "#f5f5f5",
  },
  card: {
    marginVertical: 8,
    padding: 15,
    borderRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  absentCard: {
    backgroundColor: "#f8d7da",
  },
  cardRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  dateContainer: {
    backgroundColor: "#007bff",
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  dateText: {
    color: "white",
    fontWeight: "bold",
  },
  detailsContainer: {
    flex: 1, // Takes up the remaining space
    marginLeft: 10,
  },
  cardContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  officeText: {
    fontSize: 16,
  },
  timeText: {
    fontSize: 14,
    color: "gray",
  },
  dailyText: {
    color: "red",
    fontWeight: "bold",
  },
  absentText: {
    fontWeight: "bold",
    fontSize: 16,
    color: "#721c24",
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center",
    color: "#007bff",
  },
});
