import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet,TouchableOpacity } from "react-native";
import { useAuth } from "../../auth/AuthContext";
import { getFromAPI } from "../../apicall/apicall";
import { getAPIFormat } from "../../apicall/apifFromats";
import { formatTOddmmyy, FromandToformat } from '../../shared/sharedFunctions'
import { MaterialIcons } from "@expo/vector-icons";
import Loader from '../../component/loader/Loader'
import { useNavigation } from "@react-navigation/native";


const Dashboard = () => {
  const [loading, setLoading] = useState(true);
  const [fromDate, setFromDate] = useState(() => {
    const date = new Date();
    date.setDate(1); 
    return date;
  });  
  const [toDate, setToDate] = useState(new Date());
  const [data, setData] = useState([]);
  const { user } = useAuth();
  const navigation = useNavigation();
  

  const fetchData = async () => {
    try {
      const requestData = {
        empId: user.login.employee_UID,
        fromDate: FromandToformat(fromDate),
        toDate: FromandToformat(toDate),
      };
      const response = await getFromAPI("/Dashboard/GetDashboardDetails?" + getAPIFormat(requestData));
      console.log(requestData,response)
      setData(response.data);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);



  return (
    <View style={styles.container}>
      <Loader visible={loading} />
      {data && (
        <View>
          {/* Attendance Section */}
          <View style={styles.sectionCard}>
            <Text style={styles.header}>Attendance</Text>
            <Text style={styles.header2}>{formatTOddmmyy(fromDate)} to {formatTOddmmyy(toDate)}</Text>
            
              <View style={styles.card}>
              <TouchableOpacity 
              style={styles.row} 
              onPress={() => navigation.navigate("Attendance")}
            >
                <MaterialIcons name="event-available" size={24} color="green" />
                <Text style={styles.cardText2}>{data.presentDays} <Text style={styles.cardText}>Present Days </Text> </Text>
                <MaterialIcons name="arrow-forward" size={24} color="grey" />
              </TouchableOpacity>
              <View style={styles.divider} />
              <TouchableOpacity 
              style={styles.row} 
              onPress={() => navigation.navigate("Attendance")}
            >
                <MaterialIcons name="event-busy" size={24} color="red" />
                <Text style={styles.cardText2}>{data.absentDays} <Text style={styles.cardText}>Absent Days </Text> </Text>
                <MaterialIcons name="arrow-forward" size={24} color="grey" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Service Details Section */}
          {/* <View style={styles.sectionCard}>
            <Text style={styles.header}>Service Details</Text>
            <Text style={styles.header2}>All Bookings</Text>
            <View style={styles.card}>
            <TouchableOpacity 
              style={styles.row} 
              onPress={() => navigation.navigate("RecentAttendance")}
            >
                <MaterialIcons name="work" size={24} color="blue" />
                <Text style={styles.cardText2}>{data.serviceCallBooking} <Text style={styles.cardText}>Service Booking </Text> </Text>
                <MaterialIcons name="arrow-forward" size={24} color="grey" />
              </TouchableOpacity>
              <View style={styles.divider} />
              <TouchableOpacity 
              style={styles.row} 
              onPress={() => navigation.navigate("RecentAttendance")}
            >
                <MaterialIcons name="check-circle" size={24} color="green" />
                <Text style={styles.cardText2}>{data.completedCalls} <Text style={styles.cardText}>Completed</Text> </Text>
                <MaterialIcons name="arrow-forward" size={24} color="grey" />
              </TouchableOpacity>
            </View>
          </View> */}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f5f5f5",
  },
  header: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 10,
  },
  header2: {
    fontSize: 14,
    marginBottom: 10,
  },
  sectionCard: {
    backgroundColor: "#d3d3d3", // Grey background for the section
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
  },
  card: {
    backgroundColor: "#fff", // White background inside section
    padding: 15,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between", // Ensures proper spacing
    paddingVertical: 10,
  },
  cardText: {
    fontSize: 16,
    flex: 1, // Allows text to expand naturally
    marginLeft: 10, // Space between icon and text
    fontWeight: "normal",
    color: "#382a2a",
  },
  cardText2: {
    fontSize: 20,
    flex: 1, // Allows text to expand naturally
    marginLeft: 10, // Space between icon and text
    fontWeight: "bold",
  },
  arrowIcon: {
    marginLeft: "auto", // Pushes the arrow to the right
  },
  divider: {
    height: 1,
    backgroundColor: "#d3d3d3", // Light grey line separator
    marginVertical: 5,
  },
});
export default Dashboard;
