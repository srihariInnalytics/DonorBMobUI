import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, StatusBar, Image, ActivityIndicator } from "react-native";
import { Button, Input, Icon } from "react-native-elements";
import Toast from "react-native-toast-message";
import { useAuth } from "../../auth/AuthContext";
import { colors } from "../../component/config/config";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation, useRoute } from "@react-navigation/native";
import { getFromAPI,postToAPI } from "../../apicall/apicall";
import { navigationRef } from "../../auth/NavigationService";
import { OtpInput } from "react-native-otp-entry";



const NewPin = () => {
  const navigation = navigationRef // Initialize navigation
  const [loading, setLoading] = useState(false);
  const { user, login,pinset } = useAuth();
  const route = useRoute();
  const { data } = route.params || {};

  const handleLogin = async (pin) => {
    pinset(pin);
    login(data)
  };
  

  return (
    <View style={styles.container}>
      <View style={styles.content}>

        <Image
          source={require("../../assets/industry.png")}
          style={{ width: 300, height: 300, alignSelf: "center" }}
        />
        
          <Text style={{  margin: 20,textAlign: "center",fontSize: 20,fontWeight: "bold",}}>
                Please Set New Pin
          </Text>
          <OtpInput
              numberOfDigits={4}
              onFilled={(pin) => {
                console.log("OTP entered:", pin);
                handleLogin(pin); 
              }}
              focusColor={colors.primary}
              theme={styles.theme}
            />

    

        <Toast />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  content: {
    flex: 1,
    justifyContent: "center",
    padding: 25,
  },

  title: {
    fontSize: 32,
    fontWeight: "bold",
    alignSelf: "center",
    color: "red",
    marginBottom: 20,
  },
  inputContainer: {
    marginVertical: 10,
  },
  input: {
    fontSize: 16,
  },
  loginButton: {
    backgroundColor: "#D32F2F",
    borderRadius: 5,
    marginVertical: 20,
    paddingVertical: 10,
  },

  theme: {
    containerStyle: {
      marginVertical: 20,
      justifyContent: "center",
    },
    inputsContainerStyle: {
      justifyContent: "space-evenly",
    },
    pinCodeContainerStyle: {
      borderRadius: 8,
      borderWidth: 1,
      borderColor: "#ccc",
      backgroundColor: "#f9f9f9",
      width: 45,
      height: 50,
    },
    pinCodeTextStyle: {
      fontSize: 18,
      color: "#000",
    },
  },

});

export default NewPin;

