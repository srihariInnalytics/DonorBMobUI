import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, StatusBar, Image, ActivityIndicator } from "react-native";
import { Button, Input, Icon } from "react-native-elements";
import Toast from "react-native-toast-message";
import { useAuth } from "../../auth/AuthContext";
import { colors } from "../../component/config/config";
import { LinearGradient } from "expo-linear-gradient";
import { useNavigation, useRoute } from "@react-navigation/native";
import { getFromAPI,postToAPI } from "../../apicall/apicall";
import { navigationRef } from "../../auth/NavigationService";
import { OtpInput } from "react-native-otp-entry";



const OtpScreen = () => {
  const navigation = navigationRef // Initialize navigation
  const [loading, setLoading] = useState(false);
  const { user, login } = useAuth();
  const route = useRoute();
  const { data } = route.params || {};
  const [generatedOtp, setGeneratedOtp] = useState("");



  const generateOTP = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };
  
  useEffect(() => {
    const sentOtp = async () => {
      setLoading(true);
      const otp = generateOTP(); 
      console.log("OTP:", otp);
  
      const emailData = {
        from: "",
        to: "srihari070603@gmail.com,kamalpersonal23@gmail.com",
        cc: ["hr@iecon.in"],
        subject: "IEC LOGIN OTP",
        body: `<div style='text-align:center;'>
                <p><img src='https://www.iecon.in/assets/images/logo_dark.png' alt='IEC Logo' width='100'></p>
                <h2 style='margin: 10px 0;'>IEC OTP Login</h2>
                <p style='font-size:16px;'>IEC OTP for User ${data.userName} is <b>${otp}</b></p>
              </div>`,
      };
  
      try {
        console.log("emailData" , emailData)
        const resp = await postToAPI("/sendOtp", emailData); 
  console.log("MAILLLLLL@#$%^&*(" , resp)
        if (resp.messageCode === "SUCC001") {
          Toast.show({
            type: "success",
            text1: "Success",
            text2: "OTP sent successfully",
          });
          setGeneratedOtp(otp); 
        } else {
          Toast.show({
            type: "error",
            text1: "Failed",
            text2: "Some error occurred, Try again",
          });
        }
      } catch (error) {
        Toast.show({
          type: "error",
          text1: "Error",
          text2: error.message,
        });
      } finally {
        setLoading(false);
      }
    };
  
    sentOtp(); 
  }, []);
  


  const handleLogin = async (otp) => {
    if (generatedOtp === otp) {
      navigation.navigate("NewPin", { data });
    } else {
      Toast.show({
        type: "error",
        text1: "Invalid OTP",
        text2: "Please enter the correct OTP",
      });
    }
  };
  

  return (
    <View style={styles.container}>
      <View style={styles.content}>

        <Image
          source={require("../../assets/workplace.png")}
          style={{ width: 300, height: 300, alignSelf: "center" }}
        />

        {
          loading ?
          <ActivityIndicator size={50} color={colors.primary} /> : 
          <>
          <Text style={{  margin: 20,textAlign: "center" }}>
                OTP has been sent to your registered Email ID
          </Text>
          <OtpInput
              numberOfDigits={6}
              onFilled={(otp) => {
                console.log("OTP entered:", otp);
                handleLogin(otp); 
              }}
              focusColor={colors.primary}
              theme={styles.theme}
            />

        </>

        }  
  

        <Toast />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  content: {
    flex: 1,
    justifyContent: "center",
    padding: 25,
  },

  title: {
    fontSize: 32,
    fontWeight: "bold",
    alignSelf: "center",
    color: "red",
    marginBottom: 20,
  },
  inputContainer: {
    marginVertical: 10,
  },
  input: {
    fontSize: 16,
  },
  loginButton: {
    backgroundColor: "#D32F2F",
    borderRadius: 5,
    marginVertical: 20,
    paddingVertical: 10,
  },

  theme: {
    containerStyle: {
      marginVertical: 20,
      justifyContent: "center",
    },
    inputsContainerStyle: {
      justifyContent: "space-evenly",
    },
    pinCodeContainerStyle: {
      borderRadius: 8,
      borderWidth: 1,
      borderColor: "#ccc",
      backgroundColor: "#f9f9f9",
      width: 45,
      height: 50,
    },
    pinCodeTextStyle: {
      fontSize: 18,
      color: "#000",
    },
  },

});

export default OtpScreen;

