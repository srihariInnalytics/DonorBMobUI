import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, StatusBar, Image, ActivityIndicator, TouchableOpacity } from "react-native";
import { Button, Input, Icon } from "react-native-elements";
import Toast from "react-native-toast-message";
import { useAuth } from "../../auth/AuthContext";
import { colors } from "../../component/config/config";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation, useRoute } from "@react-navigation/native";
import { getFromAPI,postToAPI } from "../../apicall/apicall";
import { navigationRef } from "../../auth/NavigationService";
import { OtpInput } from "react-native-otp-entry";
import Loader from '../../component/loader/Loader'




const LoginPin = () => {
  const navigation = navigationRef // Initialize navigation
  const [Load, setLoad] = useState(false);
  const { user, logout } = useAuth();
  const route = useRoute();
  const { data } = route.params || {};
  const [password, setPassword] = useState("");



  useEffect(() => {
    const loadUserData = async () => {
      try {
        const pin = await AsyncStorage.getItem('UserPin');
        if (pin) {
          console.log("user pin " , pin)
          setPassword(pin);
        }
      } catch (error) {
        //.error('Error loading user data:', error);
      } 
    };
    loadUserData();
  }, []);




  const handleLogin = async (pin) => {
    console.log("pin=====",pin,password)
    if (pin != password) {
      Toast.show({
        type: "error",
        text1: "Invalid Pin",
        text2: "Please enter the correct pin",
      })
    }
    else{  
      navigation.reset({
        index: 0,
        routes: [{ name: 'Admin' }], // or any initial screen inside AppNav
      });
    }
  };


  const onLogout = async () => {
      try {
        setLoad(true)
        const empId = user.login.employee_UID;
        const Api = `https://iecwebapi2024.azurewebsites.net/api/Authentication/LogOutAllDevice?empId=${empId}`;
  
        console.log("API Endpoint:", Api);
  
        const response = await fetch(Api, {
          method: "POST",
          headers: {
            "accept": "*/*",
            "SessionId": user.token.token,  // Ensure you're passing a valid session token
          },
          body: "", // Empty body since your cURL request has `-d ''`
        });
  
        const resp = await response.json();
        console.log("Response:", resp);
  
        if (resp.messageCode == "SUCC001") {
           logout();
        }
        else {
          Toast.show({
            type: "error",
            text1: "Failed",
            text2: "Some error occured, Try again",
          });
        }
  
      } catch (e) {
        console.log("ERROR:", e);
      }
      finally{
        setLoad(false)
      }
    };
  

  return (
    <View style={styles.container}>
      <Loader visible={Load} />
      <View style={styles.content}>

        <Image
          source={require("../../assets/industry.png")}
          style={{ width: 300, height: 300, alignSelf: "center" }}
        />
        
          <Text style={{  margin: 20,textAlign: "center",fontSize: 20,fontWeight: "bold",}}>
                Please Enter Your Pin
          </Text>
          <OtpInput
              numberOfDigits={4}
              onFilled={(pin) => {
                console.log("OTP entered:", pin);
                handleLogin(pin); 
              }}
              focusColor={colors.primary}
              theme={styles.theme}
            />

        <TouchableOpacity onPress={onLogout} style={{ marginTop: 30 }}>
                  <Text style={{ color: "blue", textAlign: "center", marginTop: 20 }}>
                    Forget Pin? Click here to Logout
                  </Text>
        </TouchableOpacity> 

        <Toast />
      </View>
      
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  content: {
    flex: 1,
    justifyContent: "center",
    padding: 25,
  },

  title: {
    fontSize: 32,
    fontWeight: "bold",
    alignSelf: "center",
    color: "red",
    marginBottom: 20,
  },
  inputContainer: {
    marginVertical: 10,
  },
  input: {
    fontSize: 16,
  },
  loginButton: {
    backgroundColor: "#D32F2F",
    borderRadius: 5,
    marginVertical: 20,
    paddingVertical: 10,
  },

  theme: {
    containerStyle: {
      marginVertical: 20,
      justifyContent: "center",
    },
    inputsContainerStyle: {
      justifyContent: "space-evenly",
    },
    pinCodeContainerStyle: {
      borderRadius: 8,
      borderWidth: 1,
      borderColor: "#ccc",
      backgroundColor: "#f9f9f9",
      width: 45,
      height: 50,
    },
    pinCodeTextStyle: {
      fontSize: 18,
      color: "#000",
    },
  },

});

export default LoginPin;

