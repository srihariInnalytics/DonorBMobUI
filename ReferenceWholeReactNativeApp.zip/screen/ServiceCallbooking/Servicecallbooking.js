import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from "react-native";
import { RadioButton } from "react-native-paper";
import RNPickerSelect from "react-native-picker-select";
import { MaterialIcons } from "@expo/vector-icons";

const ServiceCallForm = () => {
  const [visitType, setVisitType] = useState(null);
  const [machine, setMachine] = useState(null);
  const [visitInitiate, setVisitInitiate] = useState(null);
  const [contractType, setContractType] = useState(null);
  const [bookingDate, setBookingDate] = useState("");
  const [problemDescription, setProblemDescription] = useState("");
  const [remarks, setRemarks] = useState("");
  const [assignTo, setAssignTo] = useState("");
  const [status, setStatus] = useState("Pending");

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Service Call Booking Form</Text>

      {/* Visit Type */}
      <View style={styles.fieldContainer}>
        <MaterialIcons name="info" size={24} color="#007bff" />
        <RNPickerSelect
          onValueChange={setVisitType}
          items={[
            { label: "Routine", value: "Routine" },
            { label: "Emergency", value: "Emergency" },
          ]}
          placeholder={{ label: "Visit Type", value: null }}
          style={pickerSelectStyles}
        />
      </View>

      {/* Machine */}
      <View style={styles.fieldContainer}>
        <MaterialIcons name="settings" size={24} color="#007bff" />
        <RNPickerSelect
          onValueChange={setMachine}
          items={[
            { label: "Machine A", value: "Machine A" },
            { label: "Machine B", value: "Machine B" },
          ]}
          placeholder={{ label: "Machine", value: null }}
          style={pickerSelectStyles}
        />
      </View>

      {/* Visit Initiate */}
      <View style={styles.fieldContainer}>
        <MaterialIcons name="home" size={24} color="#007bff" />
        <RNPickerSelect
          onValueChange={setVisitInitiate}
          items={[
            { label: "By Customer", value: "By Customer" },
            { label: "By Engineer", value: "By Engineer" },
          ]}
          placeholder={{ label: "Visit Initiate", value: null }}
          style={pickerSelectStyles}
        />
      </View>

      {/* Contract Type */}
      <View style={styles.fieldContainer}>
        <MaterialIcons name="handshake" size={24} color="#007bff" />
        <RNPickerSelect
          onValueChange={setContractType}
          items={[
            { label: "AMC", value: "AMC" },
            { label: "Warranty", value: "Warranty" },
          ]}
          placeholder={{ label: "Contract Type", value: null }}
          style={pickerSelectStyles}
        />
      </View>

      {/* Booking Date */}
      <View style={styles.fieldContainer}>
        <MaterialIcons name="calendar-today" size={24} color="#007bff" />
        <TextInput
          style={styles.input}
          placeholder="Booking Date"
          value={bookingDate}
          onChangeText={setBookingDate}
        />
      </View>

      {/* Problem Description */}
      <View style={styles.fieldContainer}>
        <MaterialIcons name="info" size={24} color="#007bff" />
        <TextInput
          style={styles.input}
          placeholder="Problem Description"
          value={problemDescription}
          onChangeText={setProblemDescription}
        />
      </View>

      {/* Remarks */}
      <View style={styles.fieldContainer}>
        <MaterialIcons name="edit" size={24} color="#007bff" />
        <TextInput
          style={styles.input}
          placeholder="Remarks"
          value={remarks}
          onChangeText={setRemarks}
        />
      </View>

      {/* Assign To */}
      <View style={styles.fieldContainer}>
        <MaterialIcons name="person" size={24} color="#007bff" />
        <TextInput
          style={styles.input}
          placeholder="Assign To"
          value={assignTo}
          onChangeText={setAssignTo}
        />
      </View>

      {/* Status */}
      <View style={styles.fieldContainer}>
        <MaterialIcons name="assignment" size={24} color="#007bff" />
        <Text style={styles.statusText}>{status}</Text>
      </View>

      {/* Buttons */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.addButton}>
          <Text style={styles.buttonText}>+ Add Machine</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.saveButton}>
          <Text style={styles.saveButtonText}>Save</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default ServiceCallForm;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "#f5f5f5",
  },
  header: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
  },
  fieldContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
  },
  statusText: {
    marginLeft: 10,
    fontSize: 16,
    fontWeight: "bold",
    color: "gray",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },
  addButton: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 12,
    alignItems: "center",
    borderRadius: 5,
    borderWidth: 1,
    borderColor: "#ccc",
    marginRight: 5,
  },
  saveButton: {
    flex: 1,
    backgroundColor: "#007bff",
    padding: 12,
    alignItems: "center",
    borderRadius: 5,
  },
  buttonText: {
    color: "#007bff",
    fontWeight: "bold",
  },
  saveButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
});

const pickerSelectStyles = {
  inputIOS: {
    flex: 1,
    fontSize: 16,
    marginLeft: 10,
  },
  inputAndroid: {
    flex: 1,
    fontSize: 16,
    marginLeft: 10,
  },
};
