import { View, Dimensions, Text, FlatList, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import React, { useState, useEffect } from "react";
import { postToAPI, getFromAPI, putToAPI } from '../../../apicall/apicall'
import { getAPIFormat } from '../../../apicall/apifFromats'
import { useAuth } from '../../../auth/AuthContext'
import { formatTOddmmyy, formatDateTimeFromApiToUITimeOnly, DateTimePickerToApiFormat, getCurrDateTime, mergeDateTimeforDatePicker } from '../../../shared/sharedFunctions'
import Loader from '../../../component/loader/Loader'
import DropdownComponent from '../../../component/dropdown2/DropDown';
import { MaterialIcons } from "@expo/vector-icons";
import { Dialog, Portal } from "react-native-paper";
import { Button } from "react-native-elements";
import Toast from "react-native-toast-message";


const leaveApproval = () => {
  const { width, height } = Dimensions.get('window');
  const [Load, setLoad] = useState(false)
  const { user } = useAuth();
  const [MainDataPending, setMainDataPending] = useState([])
  const [MainDataCompleted, setMainDataCompleted] = useState([])
  const [EmployeesDD, setEmployeesDD] = useState([])
  const [Employee, setEmployee] = useState(0)
  const [activeTab, setActiveTab] = useState("Pending"); // "Pending" | "Completed"
  const [Show, setShow] = useState(true); // true to show pending adn false to show completed
  const [PopupVis, setPopupVis] = useState(false);
  const [PopupType, setPopupType] = useState(true); // popup is acept or reject true = acept , false = reject
  const [ActionItem, setActionItem] = useState({});


  const StatusColor = {
    1: '#FFD700',   // Yellow for Pending
    2: '#28a745',   // Green for Approved
    4: '#FF0000',     // Bright Red for Cancelled
  };

  const handleAccept = async (item) => {
    try {
      setLoad(true)
      let Data = { ...item }
      Data.modifiedBy = user.login.employee_UID
      Data.modifiedDate = getCurrDateTime()
      Data.status = 2
      const response = await putToAPI('/UpdateLeave', Data)
      console.log("DataToAPI ", Data)
      console.log("RESPONSE ", response)
      if (response.messageCode == "SUCC001") {
        Toast.show({
          type: "success",
          text1: "Approved",
          text2: "Leave Approved Successfully",
        });
      }
      else {
        Toast.show({
          type: "error",
          text1: "Something went wrong",
          text2: "Please try again...",
        });
      }
    }
    catch (e) {
      console.log("Eror ", e)
    }
    finally {
      setLoad(false);
      fetchAfterPendingPUT()
      setPopupVis(false)
    }
  };

  const handleReject = async (item) => {
    try {
      setLoad(true)
      let Data = { ...item }
      Data.modifiedBy = user.login.employee_UID
      Data.modifiedDate = getCurrDateTime()
      Data.status = 3
      console.log("DataToAPI ", Data)
      const response = await putToAPI('/UpdateLeave', Data)
      console.log("RESPONSE ", response)
      if (response.messageCode == "SUCC001") {
        Toast.show({
          type: "success",
          text1: "Rejected",
          text2: "Leave Rejected Successfully",
        });
      }
      else {
        Toast.show({
          type: "error",
          text1: "Something went wrong",
          text2: "Please try again...",
        });
      }
    }
    catch (e) {
      console.log("Eror ", e)
    }
    finally {
      setLoad(false)
      fetchAfterPendingPUT()
      setPopupVis(false)
    }
  };

  const fetchDataInitial = async () => {
    try {
      setLoad(true)
      const DataToAPI1 = {
        employeeUid: 0, // all
        rollId: user.login.app_RollUID // user's uid
      };
      const [res1, res2, res3] = await Promise.all([
        getFromAPI('/Admin/Get-all-leave/Pending?' + getAPIFormat(DataToAPI1)),
        getFromAPI('/Attendance/GetUserDetails'), //  5
        getFromAPI('/Admin/Get-all-leave/Completed?' + getAPIFormat(DataToAPI1)),
      ]);
      setMainDataPending(res1.data)
      setEmployeesDD(res2.data)
      setMainDataCompleted(res3.data)
      // console.log("🔹 Data to api", DataToAPI1)
      console.log("✅ Response  from Pending :", res3.data[0]);
    } catch (e) {
      console.error("❌ Error from Permission Request:", e);
    } finally {
      setLoad(false)
    }
  };

  useEffect(() => {
    fetchDataInitial() //initial api cal for Pending
  }, [])


  const fetchAfterPendingPUT = async () => {
    try {
      setLoad(true)
      const DataToAPI1 = {
        employeeUid: Employee, // all
        rollId: user.login.app_RollUID // user's uid
      };
      const [res1] = await Promise.all([
        getFromAPI('/Admin/Get-all-leave/Pending?' + getAPIFormat(DataToAPI1)),
      ]);
      setMainDataPending(res1.data)
    } catch (e) {
      console.error("❌ Error from Permission Request:", e);
    } finally {
      setLoad(false)
    }
  };

  const SearchByEmployeePending = async (e) => {
    try {
      setLoad(true)
      console.log("INSIDE PENDING DD ")
      setEmployee(e);
      const DataToAPI1 = {
        employeeUid: e, // all
        rollId: user.login.app_RollUID // user's uid
      };
      const [res1] = await Promise.all([
        getFromAPI('/Admin/Get-all-leave/Pending?' + getAPIFormat(DataToAPI1)),
      ]);
      setMainDataPending(res1.data)
    }
    catch (e) {
      console.log("Error in PENSDING FECTH DD", e)
    }
    finally {
      setLoad(false)
    }
  }

  const SearchByEmployeeCompleted = async (e) => {
    try {
      setLoad(true)
      console.log("INSIDE COMPLETED DD ")
      setEmployee(e);
      const DataToAPI1 = {
        employeeUid: e, // all
        rollId: user.login.app_RollUID // user's uid
      };
      const [res1] = await Promise.all([
        getFromAPI('/Admin/Get-all-leave/Completed?' + getAPIFormat(DataToAPI1)),
      ]);
      setMainDataCompleted(res1.data)
    }
    catch (e) {
      console.log("ERROR  IN COMPLETED FETCH", e)
    }
    finally {
      setLoad(false)
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tabButton, activeTab === "Pending" && styles.activeTab]}
          onPress={() => {
            setActiveTab("Pending");
            setShow(true)
          }}
        >
          <Text style={styles.tabText}>Pending</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tabButton, activeTab === "Completed" && styles.activeTab]}
          onPress={() => {
            setActiveTab("Completed");
            setShow(false)
          }}
        >
          <Text style={styles.tabText}>Completed</Text>
        </TouchableOpacity>
      </View>

      <View style={{ marginBottom: 5 }}>
        <DropdownComponent
          data={EmployeesDD} // API response data
          setSelectdp={(e) => {
            Show ? SearchByEmployeePending(e) : SearchByEmployeeCompleted(e)
          }}
          Selectdp={Employee} // The selected category value
          disabled={false}
          heading="Select Employee"
          label="name" // Display field
          value="uId" // Actual value field
        />
      </View>


      <Loader visible={Load} />
      {Show ?
        <>
          {MainDataPending.length == 0 &&
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
              <MaterialIcons name="inbox" size={Math.min(width, height) * 0.4} color="#ccc" />
              <Text style={{ marginTop: 20, fontSize: 18, color: '#888' }}>There is no data</Text>
            </View>}
          <FlatList
            data={MainDataPending}
            keyExtractor={(item) => item.uid}
            renderItem={({ item }) => (
              <View style={styles.card}>

                <View style={styles.row}>
                  <Text style={styles.label}>Name:</Text>
                  <Text style={styles.value}>{item.employee}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>From Date:</Text>
                  <Text style={styles.value}>{formatTOddmmyy(item.fromDate)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>To Date:</Text>
                  <Text style={styles.value}>{formatTOddmmyy(item.toDate)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Leave Type:</Text>
                  <Text style={styles.value}>
                    {item.timeFlag == 0 ? "Full Day" : "Half Day"}
                  </Text>
                </View>

                {item.timeFlag != 0 && <View style={styles.row}>
                  <Text style={styles.label}>Leave Session:</Text>
                  <Text style={styles.value}>
                    {item.timeFlag == 1 ? "Forenoon" : "Afternoon"}
                  </Text>
                </View>
                }

                <View style={styles.row}>
                  <Text style={styles.label}>Reason:</Text>
                  <Text style={styles.value}>{item.remark}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Status:</Text>
                  <Text
                    style={[
                      styles.status,
                      item.status !== 3 && { color: StatusColor[item.status] } // No color for Rejected
                    ]}
                  >
                    {item.status === 2 && "Approved" ||
                      item.status === 4 && "Cancelled" ||
                      item.status === 3 && "Rejected" ||
                      item.status === 1 && "Pending"}
                  </Text>
                </View>

                {/* Cancel Button */}
                <View style={{ flexDirection: "row", justifyContent: " space-between", gap: 2 }}>
                  <TouchableOpacity style={styles.AcceptButton} onPress={() => { setActionItem(item); setPopupType(true); setPopupVis(true) }}> {/*handleAccept(item) */}
                    <Text style={styles.buttonTextAccept}>Accept</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.RejectButton} onPress={() => { setActionItem(item); setPopupType(false); setPopupVis(true) }}> {/* handleReject(item) */}
                    <Text style={styles.buttonTextReject}>Reject</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
          {/* popup  starts ---- */}
          <Portal>
            <Dialog visible={PopupVis} onDismiss={() => setPopupVis(false)}>
              <Dialog.Title>Confirmation</Dialog.Title>
              <Dialog.Content>
                {PopupType ?
                  <Text>Are you sure you want to Accept this?</Text>
                  :
                  <Text>Are you sure you want to Reject this?</Text>
                }
              </Dialog.Content>
              <Dialog.Actions style={{ flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 10 }}>
                <Button
                  title="Yes"
                  buttonStyle={{ backgroundColor: "green", width: "80%" }}
                  onPress={() => {
                    if (PopupType) {
                      console.log("1111111111")
                      handleAccept(ActionItem)
                      setActionItem({})
                    }
                    else {
                      console.log("22222222")
                      handleReject(ActionItem)
                      setActionItem({})
                    }
                  }
                  }
                />
                <Button
                  title="No"
                  buttonStyle={{ backgroundColor: "red", width: "80%" }}
                  onPress={() => setPopupVis(false)}
                />
              </Dialog.Actions>
            </Dialog>
          </Portal>
          {/* popup  ends ---- */}

        </> :
        <>
          {MainDataCompleted.length == 0 &&
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
              <MaterialIcons name="inbox" size={Math.min(width, height) * 0.4} color="#ccc" />
              <Text style={{ marginTop: 20, fontSize: 18, color: '#888' }}>There is no data</Text>
            </View>}
          <FlatList
            data={MainDataCompleted}
            keyExtractor={(item) => item.uid}
            renderItem={({ item }) => (
              <View style={styles.card}>

                <View style={styles.row}>
                  <Text style={styles.label}>Name:</Text>
                  <Text style={styles.value}>{item.employee}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>From Date :</Text>
                  <Text style={styles.value}>{formatTOddmmyy(item.fromDate)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>To Date :</Text>
                  <Text style={styles.value}>{formatTOddmmyy(item.toDate)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Leave Type:</Text>
                  <Text style={styles.value}>
                    {item.timeFlag == 0 ? "Full Day" : "Half Day"}
                  </Text>
                </View>

                {item.timeFlag != 0 && <View style={styles.row}>
                  <Text style={styles.label}>Leave Session:</Text>
                  <Text style={styles.value}>
                    {item.timeFlag == 1 ? "Forenoon" : "Afternoon"}
                  </Text>
                </View>
                }
                <View style={styles.row}>
                  <Text style={styles.label}>Reason:</Text>
                  <Text style={styles.value}>{item.remark}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Status:</Text>
                  <Text
                    style={[
                      styles.status,
                      item.status !== 3 && { color: StatusColor[item.status] } // No color for Rejected
                    ]}
                  >
                    {item.status === 2 && "Approved" ||
                      item.status === 4 && "Cancelled" ||
                      item.status === 3 && "Rejected" ||
                      item.status === 1 && "Pending"}
                  </Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Modified By:</Text>
                  <Text style={styles.value}>
                    {item.modifiedBy}
                  </Text>
                </View>

              </View>
            )}
          />
        </>
      }
    </View>
  )
}

export default leaveApproval

const styles = StyleSheet.create({
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1, // ✅ Added border for consistency
    borderColor: "grey", // ✅ Dull Red Border
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },
  timeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  timeBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    flex: 1,
    justifyContent: "center",
    marginRight: 5,
    borderWidth: 1, // ✅ Added border
    borderColor: "black", // ✅ Dull Red Border
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Input Text
  },
  submitButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
  },
  showFormButton: {
    backgroundColor: "#D32F2F", // ✅ Dull Red Show Form Button
    padding: 12,
    alignItems: "center",
    borderRadius: 5,
    marginBottom: 10,
  },
  submitText: {
    color: "#D32F2F",
    fontWeight: "bold",
  },
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "#f5f5f5",
  },
  card: {
    backgroundColor: "#FFF",
    padding: 20,
    borderRadius: 10,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
    padding: 5
  },
  label: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
    color: "black",
  },
  value: {
    fontSize: 18, // Increased font size
    color: "#333",
  },
  status: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
  },
  floatingButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    width: 70, // Increased size
    height: 70,
    borderRadius: 35,
    backgroundColor: "#D32F2F",
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  AcceptButton: {
    flex: 1,
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#28a745",  // ✅ Outline color
    alignItems: "center"
  },
  RejectButton: {
    flex: 1,
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
    alignItems: "center"
  },
  buttonTextAccept: {
    color: "#28a745",  // ✅ Same color as border
    fontSize: 18,
    fontWeight: "bold",

  },
  buttonTextReject: {
    color: "#D32F2F",  // ✅ Same color as border
    fontSize: 18,
    fontWeight: "bold",
  },
  errorText: {
    color: "red",
    fontSize: 12,
    marginTop: 5,
  },
  backText: {
    color: "#007bff",
    fontWeight: "bold",
  },
  backButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#007bff",  // ✅ Outline color
  },

  tabContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 10,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 10,
    backgroundColor: "#f0f0f0",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ccc",
  },
  activeTab: {
    backgroundColor: "#D0E8FF", // Your theme green
  },
  tabText: {
    color: "black",
    fontWeight: "bold",
  },

});