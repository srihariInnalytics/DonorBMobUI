import React, { useState, useEffect, useLayoutEffect, useCallback } from 'react';
import { View, Dimensions, Text, StyleSheet, FlatList, TouchableOpacity, ScrollView } from "react-native";
import { useAuth } from "../../../auth/AuthContext";
import { getFromAPI } from "../../../apicall/apicall";
import { getAPIFormat } from "../../../apicall/apifFromats";
import { MaterialIcons } from "@expo/vector-icons";
import Loader from '../../../component/loader/Loader'
import { useNavigation } from "@react-navigation/native";
import DateTimePicker from "@react-native-community/datetimepicker";
import DropdownComponent from '../../../component/dropdown2/DropDown';
import { formatTOddmmyy, formatDateTimeFromApiToUITimeOnly, DateTimePickerToApiFormat, FromandToformat, mergeDateTimeforDatePicker } from '../../../shared/sharedFunctions'
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ExcelJS from "exceljs";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import Toast from "react-native-toast-message";

const leaveReport = () => {
  const { width, height } = Dimensions.get('window');
  const [Load, setLoad] = useState(false)
  const [MainData, setMainData] = useState([]);
  const { user } = useAuth();
  const navigation = useNavigation();
  const [EmployeesDD, setEmployeesDD] = useState([])
  const [Employee, setEmployee] = useState(0)
  console.log(Employee,"user")

  //---
  const [date1, setDate1] = useState(() => {
        const date = new Date();
        date.setDate(1); 
        return date;
      }); // for leave date
  const [date2, setDate2] = useState(new Date()); // for leave date
  const [showFromTimePicker, setShowFromTimePicker] = useState(false);
  const [showToTimePicker, setShowToTimePicker] = useState(false);
  //---
  function resetDate(date) {
    // Return just the date part, without the time
    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
  }
  
  const fetchDataInitial = async () => {
    try {
      setLoad(true)
      const DataToAPI1 = {
        employeeUid: 0, // all
        rollId: user.login.app_RollUID, // user's uid
        fromDate: FromandToformat(date1),
        toDate: FromandToformat(date2),
      };

      console.log("✅ ✅ ✅ ✅ ✅ data to api", DataToAPI1)

      const [res1, res2] = await Promise.all([
        getFromAPI('/Admin/Get-all-leave/LeaveReport?' + getAPIFormat(DataToAPI1)),
        getFromAPI('/Attendance/GetUserDetails'), //  5
      ]);
      setMainData(res1.data)
      setEmployeesDD(res2.data)
    } catch (e) {
      console.error("❌ Error from Permission Request:", e);
    } finally {
      setLoad(false)
    }
  };
  useEffect(() => {
    fetchDataInitial();
  }, []);

  const fetchAfterSelection = async () => {
    try {
      setLoad(true)
      const DataToAPI1 = {
        employeeUid: Employee, // all
        rollId: user.login.app_RollUID, // user's uid
        fromDate: FromandToformat(date1),
        toDate: FromandToformat( date2),
      };
      console.log("DATA TO API ", DataToAPI1)
      const [res1] = await Promise.all([
        getFromAPI('/Admin/Get-all-leave/LeaveReport?' + getAPIFormat(DataToAPI1)),
      ]);
      setMainData(res1.data)
      console.log("✅ Response AFTER SELECTION :", res1.data[0]);
    } catch (e) {
      console.error("❌ Error from Permission Request:", e);
    } finally {
      setLoad(false)
    }
  }


  const downloadExcelFile = async () => {
    setLoad(true)
    if (!MainData || MainData.length === 0) {
      alert("No data to export");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("LeaveReport");

    worksheet.columns = [
      { header: "S.No", key: "sno", width: 6 },
      { header: "Date", key: "date", width: 15 },
      { header: "Name", key: "name", width: 25 },
      { header: "Leave Type", key: "leaveType", width: 15 },
      { header: "Status", key: "status", width: 15 },
    ];

    const getStatusInfo = (status) => {
      switch (status) {
        case 2:
          return { text: "Approved", color: "FFDFF6DD" }; // Light Green
        case 4:
          return { text: "Cancelled", color: "FFD9EFFF" }; // Light Blue
        case 3:
          return { text: "Rejected", color: "FFFFD9DC" }; // Light Red
        case 1:
          return { text: "Pending", color: "FFFFF8D5" }; // Light Yellow
        default:
          return { text: "Unknown", color: "FFE9ECEF" }; // Light Gray
      }
    };

    MainData.forEach((item, index) => {
      const status = getStatusInfo(item.status);

      const row = worksheet.addRow({
        sno: index + 1,
        date: formatTOddmmyy(item?.fromDate),
        name: item?.employee,
        leaveType: item?.timeFlag === 0 ? "Full Day" : "Half Day",
        status: status.text,
      });

      const statusCell = row.getCell("status");
      statusCell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: status.color },
      };

      statusCell.font = {
        color: { argb: "FF000000" }, // Black text
        bold: true,
      };
    });

    const buffer = await workbook.xlsx.writeBuffer();

    const fileName = "LeaveReport.xlsx";
    download(fileName, buffer);

    setLoad(false)
  };

  const download = async (fileName, buffer) => {
    try {
      const base64 = buffer.toString('base64');
      const mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
      const tempFileUri = FileSystem.documentDirectory + `${fileName}.xlsx`;

      await FileSystem.writeAsStringAsync(tempFileUri, base64, {
        encoding: FileSystem.EncodingType.Base64,
      });

      if (Platform.OS === 'android') {
        let savedUri = await AsyncStorage.getItem('DIRECTORY_URI');

        // If no saved URI, request permissions
        if (!savedUri) {
          const permissions = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
          if (permissions.granted) {
            savedUri = permissions.directoryUri;
            await AsyncStorage.setItem('DIRECTORY_URI', savedUri); // Save it for next time
          } else {
            Sharing.shareAsync(tempFileUri);
            return;
          }
        }

        try {
          const fileUri = await FileSystem.StorageAccessFramework.createFileAsync(
            savedUri,
            fileName,
            mimeType
          );

          await FileSystem.writeAsStringAsync(fileUri, base64, {
            encoding: FileSystem.EncodingType.Base64,
          });

          Toast.show({
            type: 'success',
            text1: 'File downloaded successfully 📁',
          });
        } catch (e) {
          console.log('SAF Error:', e);
          Toast.show({
            type: 'error',
            text1: 'Failed to save using SAF',
          });
        }
      } else {
        Sharing.shareAsync(tempFileUri);
      }
    } catch (error) {
      console.error("Download error:", error);
      Toast.show({
        type: "error",
        text1: "Failed to download",
      });
    }
  };

  const exportToExcel = async () => {
    setLoad(true)
    if (!MainData || MainData.length === 0) {
      alert("No data to export");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("LeaveReport");

    worksheet.columns = [
      { header: "S.No", key: "sno", width: 6 },
      { header: "Date", key: "date", width: 15 },
      { header: "Name", key: "name", width: 25 },
      { header: "Leave Type", key: "leaveType", width: 15 },
      { header: "Status", key: "status", width: 15 },
    ];

    const getStatusInfo = (status) => {
      switch (status) {
        case 2:
          return { text: "Approved", color: "FFDFF6DD" }; // Light Green
        case 4:
          return { text: "Cancelled", color: "FFD9EFFF" }; // Light Blue
        case 3:
          return { text: "Rejected", color: "FFFFD9DC" }; // Light Red
        case 1:
          return { text: "Pending", color: "FFFFF8D5" }; // Light Yellow
        default:
          return { text: "Unknown", color: "FFE9ECEF" }; // Light Gray
      }
    };

    MainData.forEach((item, index) => {
      const status = getStatusInfo(item.status);

      const row = worksheet.addRow({
        sno: index + 1,
        date: formatTOddmmyy(item?.fromDate),
        name: item?.employee,
        leaveType: item?.timeFlag === 0 ? "Full Day" : "Half Day",
        status: status.text,
      });

      const statusCell = row.getCell("status");
      statusCell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: status.color },
      };

      statusCell.font = {
        color: { argb: "FF000000" }, // Black text
        bold: true,
      };
    });

    const buffer = await workbook.xlsx.writeBuffer();

    const filePath = FileSystem.cacheDirectory + "LeaveReport.xlsx";
    await FileSystem.writeAsStringAsync(filePath, buffer.toString("base64"), {
      encoding: FileSystem.EncodingType.Base64,
    });

    await Sharing.shareAsync(filePath, {
      mimeType:
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      dialogTitle: "Share Leave Report Excel",
      UTI: "com.microsoft.excel.xlsx",
    });
    setLoad(false)
  };

  useEffect(() => {
    fetchAfterSelection()
  }, [Employee, date1, date2]);

  return (
    <View style={styles.container}>
      <Loader visible={Load} />

      {/* Filters */}
      <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 10 }}>
        {/* From Date Picker */}
        <TouchableOpacity
          style={[styles.inputContainer, { flex: 1, marginRight: 5, marginTop: 10 }]}
          onPress={() => setShowFromTimePicker(true)}
        >
          <MaterialIcons name="calendar-today" size={24} color="#007bff" />
          <View>
            <Text style={styles.inputText}>From:</Text>
            <Text style={styles.inputText}>{date1.toLocaleDateString()}</Text>
          </View>
        </TouchableOpacity>

        {showFromTimePicker && (
          <DateTimePicker
            value={date1}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              setShowFromTimePicker(false);
              if (selectedDate) setDate1(selectedDate);
            }}
          />
        )}

        {/* To Date Picker */}
        <TouchableOpacity
          style={[styles.inputContainer, { flex: 1, marginHorizontal: 5, marginTop: 10 }]}
          onPress={() => setShowToTimePicker(true)}
        >
          <MaterialIcons name="calendar-today" size={24} color="#007bff" />
          <View>
            <Text style={styles.inputText}>To:</Text>
            <Text style={styles.inputText}>{date2.toLocaleDateString()}</Text>
          </View>
        </TouchableOpacity>

        {showToTimePicker && (
          <DateTimePicker
            value={date2}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              setShowToTimePicker(false);
              if (selectedDate) setDate2(selectedDate);
            }}
          />
        )}

        {/* Dropdown */}
        <View style={{ flex: 1, marginLeft: 5 }}>
          <DropdownComponent
            data={EmployeesDD}
            setSelectdp={(e) => setEmployee(e)}
            Selectdp={Employee}
            disabled={false}
            heading="Select Employee"
            label="name"
            value="uId"
          />
        </View>
      </View>


      {/* Scrollable table */}
      <ScrollView horizontal>
        <View>
          {/* Table Header */}
          <View style={styles.headerRow}>
            <Text style={[styles.headerCell, { width: 120 }]}>S.No</Text>
            <Text style={[styles.headerCell, { width: 150 }]}>Date</Text>
            <Text style={[styles.headerCell, { width: 120 }]}>Name</Text>
            <Text style={[styles.headerCell, { width: 120 }]}>Leave Type</Text>
            <Text style={[styles.headerCell, { width: 120 }]}>Status</Text>
          </View>

          {/* Table Body */}
          <FlatList
            data={MainData}
            keyExtractor={(item, index) => item.uId?.toString() || index.toString()}
            renderItem={({ item, index }) => (
              <View style={styles.row}>
                <Text style={[styles.cell, { width: 120 }]}>{index + 1}</Text>
                <Text style={[styles.cell, { width: 150 }]}>{formatTOddmmyy(item?.fromDate)}</Text>
                <Text style={[styles.cell, { width: 120 }]}>{item?.employee}</Text>
                <Text style={[styles.cell, { width: 120 }]}>
                  {item.timeFlag == 0 ? "Full Day" : "Half Day"}
                </Text>
                <Text style={[styles.cell, { width: 120 }]}>
                  {item.status === 2 && "Approved" ||
                    item.status === 4 && "Cancelled" ||
                    item.status === 3 && "Rejected" ||
                    item.status === 1 && "Pending"}
                </Text>
              </View>
            )}
            ListEmptyComponent={
              <Text style={{ textAlign: "center", marginTop: 20, color: "red" }}>No data available</Text>
            }
          />
        </View>
      </ScrollView>


      {/* Floating Download Button (always visible) */}
      <TouchableOpacity onPress={exportToExcel} style={styles.floatingButton}>
        <MaterialIcons name="share" size={30} color="white" />
      </TouchableOpacity>

      <TouchableOpacity onPress={downloadExcelFile} style={styles.floatingButton2}>
        <MaterialIcons name="download" size={30} color="white" />
      </TouchableOpacity>
    </View>
  );

}

export default leaveReport

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: "#f9f9f9",
  },
  title: {
    fontSize: 15,
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 10,
  },

  // Header Styles
  headerRow: {
    flexDirection: "row",
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
  },
  headerCell: {
    width: 120,  // Set specific width for each column
    fontWeight: "bold",
    color: "white",
    textAlign: "center",
    paddingHorizontal: 5,
  },

  // Table Row Styles
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
  },
  evenRow: { backgroundColor: "#f2f2f2" },
  oddRow: { backgroundColor: "#ffffff" },
  absentRow: { backgroundColor: "#ffcccc" }, // Red for absent
  cell: {
    width: 120,  // Ensure it matches the header width
    textAlign: "center",
    paddingVertical: 5,
    paddingHorizontal: 5,
  },
  floatingButton: {
    position: "absolute",
    bottom: 30,
    right: 20,
    width: 70, // Increased size
    height: 70,
    borderRadius: 35,
    backgroundColor: "#D32F2F",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",

  },
  floatingButton2: {
    position: "absolute",
    bottom: 30,
    right: 100,
    width: 70, // Increased size
    height: 70,
    borderRadius: 35,
    backgroundColor: "green",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",

  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1, // ✅ Added border for consistency
    borderColor: "grey", // ✅ Dull Red Border
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },

});