import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ScrollView, Platform } from "react-native";
import DateTimePicker from '@react-native-community/datetimepicker';
import { useAuth } from "../../../auth/AuthContext";
import { getFromAPI } from "../../../apicall/apicall";
import { getAPIFormat } from "../../../apicall/apifFromats";
import { formatTOddmmyy, FromandToformat, getTimeDiff } from '../../../shared/sharedFunctions';
import { MaterialIcons } from "@expo/vector-icons";
import Loader from '../../../component/loader/Loader';
import { useNavigation } from "@react-navigation/native";

const attendanceReport = () => {
  const [Loading, setLoading] = useState(false);
  const [MainData, setMainData] = useState([]);
  const [fromDate, setFromDate] = useState(new Date());
  const [showPicker, setShowPicker] = useState(false);
  const { user } = useAuth();
  const navigation = useNavigation();

  const fetchData = async (date = fromDate) => {
    setLoading(true);
    try {
      const requestData = {
        fromDate: FromandToformat(date),
      };
      const response = await getFromAPI("/Attendance/DailyAttendaceReport?" + getAPIFormat(requestData));
      setMainData(response.data);
    } catch (error) {
      console.error("Error fetching attendance data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const onChangeDate = (event, selectedDate) => {
    setShowPicker(false);
    if (selectedDate) {
      setFromDate(selectedDate);
      fetchData(selectedDate);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Daily Attendance Report</Text>
      <Loader visible={Loading} />

      {/* 🔍 Date Picker Button */}
      <View style={{ alignItems: 'center', marginBottom: 10 }}>
        <TouchableOpacity onPress={() => setShowPicker(true)} style={styles.dateButton}>
           <MaterialIcons name="calendar-today" size={24} color="#007bff" />      
          <Text style={ styles.inputText }>Date: {formatTOddmmyy(fromDate)}</Text>
        </TouchableOpacity>
        {showPicker && (
          <DateTimePicker
            value={fromDate}
            mode="date"
            display={Platform.OS === 'ios' ? 'inline' : 'default'}
            onChange={onChangeDate}
          />
        )}
      </View>

      {/* Table Header & Body */}
      <ScrollView horizontal>
        <View>
          <View style={styles.headerRow}>
            <Text style={[styles.headerCell, { width: 120 }]}>S.No</Text>
            <Text style={[styles.headerCell, { width: 150 }]}>Name</Text>
            <Text style={[styles.headerCell, { width: 120 }]}>Designation</Text>
            <Text style={[styles.headerCell, { width: 120 }]}>Date</Text>
            <Text style={[styles.headerCell, { width: 120 }]}>Punch In</Text>
            <Text style={[styles.headerCell, { width: 120 }]}>Punch Out</Text>
            <Text style={[styles.headerCell, { width: 120 }]}>Working Time</Text>
            <Text style={[styles.headerCell, { width: 120 }]}>Remarks</Text>
          </View>

          <FlatList
            data={MainData}
            keyExtractor={(item, index) => item.uId?.toString() || index.toString()}
            renderItem={({ item, index }) => (
              <View style={[
                styles.row,
                item.status !== "Present" ? styles.absentRow : index % 2 === 0 ? styles.evenRow : styles.oddRow
              ]}>
                <Text style={[styles.cell, { width: 120 }]}>{index + 1}</Text>
                <Text style={[styles.cell, { width: 150 }]}>{item?.name}</Text>
                <Text style={[styles.cell, { width: 120 }]}>{item?.designation}</Text>
                <Text style={[styles.cell, { width: 120 }]}>{formatTOddmmyy(item?.date)}</Text>
                <Text style={[styles.cell, { width: 120 }]}>{item?.punchin}</Text>
                <Text style={[styles.cell, { width: 120 }]}>{item?.punchout}</Text>
                <Text style={[styles.cell, { width: 120 }]}>
                  {getTimeDiff(item.punchInTime, item.punchOutTime) > 0
                    ? `${getTimeDiff(item.punchInTime, item.punchOutTime)} hrs`
                    : '0'}
                </Text>
                <Text style={[styles.cell, { width: 120 }]}>{item?.remark}</Text>
              </View>
            )}
            initialNumToRender={20}
            maxToRenderPerBatch={50}
            windowSize={5}
            ListEmptyComponent={
              <Text style={{ textAlign: "center", marginTop: 20, color: "red" }}>
                No data available
              </Text>
            }
          />
        </View>
      </ScrollView>

      {MainData.length > 0 &&
        <TouchableOpacity onPress={() => navigation.navigate("Reports")} style={styles.floatingButton}>
          <MaterialIcons name="download" size={30} color="white" />
        </TouchableOpacity>
      }
    </View>
  );
};

export default attendanceReport;

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10, backgroundColor: "#f9f9f9" },
  title: {
    fontSize: 15,
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 10,
  },
  dateButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1, // ✅ Added border for consistency
    borderColor: "grey", // ✅ Dull Red Border
  },
  headerRow: {
    flexDirection: "row",
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
  },
  headerCell: {
    width: 120,
    fontWeight: "bold",
    color: "white",
    textAlign: "center",
    paddingHorizontal: 5,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
  },
  evenRow: { backgroundColor: "#f2f2f2" },
  oddRow: { backgroundColor: "#ffffff" },
  absentRow: { backgroundColor: "#ffcccc" },
  cell: {
    width: 120,
    textAlign: "center",
    paddingVertical: 5,
    paddingHorizontal: 5,
  },
  floatingButton: {
    position: "absolute",
    bottom: 60,
    right: 20,
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: "#D32F2F",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },
});
