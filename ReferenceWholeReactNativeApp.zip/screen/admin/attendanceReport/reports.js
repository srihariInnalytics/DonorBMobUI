import React, { useState, useEffect } from "react";
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import { MaterialIcons } from "@expo/vector-icons";
import { postToAPI, getFromAPI } from '../../../apicall/apicall'
import { getAPIFormat } from '../../../apicall/apifFromats'
import { useAuth } from '../../../auth/AuthContext'
import { FromandToformat,formatTOddmmyy,formatDateTimeFromApiToUITimeOnly } from '../../../shared/sharedFunctions'
import Loader from '../../../component/loader/Loader'
import Toast from "react-native-toast-message";
import DropdownComponent from '../../../component/dropdown2/DropDown';
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';
import ExcelJS from "exceljs";
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';




const LeaveRequestForm = () => {
  const [Load, setLoad] = useState(false)
  const [fromDate, setFromDate] = useState(new Date()); 
  const [toDate, setToDate] = useState(new Date());
  const [showFromTimePicker, setShowFromTimePicker] = useState(false);
  const [showToTimePicker, setShowToTimePicker] = useState(false);
 
  const [ReportTypeDD, setReportTypeDD] = useState([
    { Description: "Daily Attendance Report", UID: 1 },
    { Description: "Monthly Attendance Report", UID: 2 },
    { Description: "User Wise Attendance Report", UID: 3 },


  ]);
  const [ReportType, setReportType] = useState(ReportTypeDD[0].UID); // Default selected value
  const [UserData, setUserData] = useState([]);
  const [User, setUser] = useState(null); 
  const { user } = useAuth();
  



  const dailyExcelFile = async (data, fileName,settings) => {
      // Convert your JSON data to a worksheet
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet(fileName);


      const headers = [
        { header: "S.No", key: "sno", width: 6 },
        { header: "Department", key: "department", width: 15 },
        { header: "Employee Name", key: "employeeName", width: 20 },
        { header: "Date", key: "date", width: 15 },
        { header: "Attendance Location", key: "attendanceLocation", width: 20 },
        { header: "Map Location", key: "mapLocation", width: 20 },
        { header: "Punch In Time", key: "punchInTime", width: 15 },
        { header: "Punch Out Time", key: "punchOutTime", width: 15 },
        { header: "Punch In Status", key: "punchInStatus", width: 15 },
        { header: "Remarks", key: "remarks", width: 20 },
        { header: "Status", key: "status", width: 15 },
      ];
  
      worksheet.columns = headers;

      // Make header row bold and increase font size
      worksheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: true};
      });
  
      // Format and add each data row
      data.forEach((item, index) => {
        const row = worksheet.addRow({
          sno: index + 1,
          department: item.designation,
          employeeName: item.name,
          date: formatTOddmmyy(item.date),
          attendanceLocation: item.location,
          mapLocation: `${item.latitude},${item.longitude}`,
          punchInTime: item.punchin,
          punchOutTime: item.punchout,
          punchInStatus: item.punchInStatus,
          remarks: item.remark,
          status: item.status,
        });
  
        // Highlight "absent" rows in red
        if (item.status?.toLowerCase() === 'absent') {
          row.eachCell((cell) => {
            cell.fill = {
              type: 'pattern',
              pattern: 'solid',
              fgColor: { argb: 'ffcccc' },
            };
          });
        }
        if (item.status?.toLowerCase() === 'leave request') {
          row.eachCell((cell) => {
            cell.fill = {
              type: 'pattern',
              pattern: 'solid',
              fgColor: { argb: 'ebe16a' },
            };
          });
        }
      });
          
  
      // Generate the file buffer
      const buffer = await workbook.xlsx.writeBuffer();

      if(settings === 'download') {
        download(fileName, buffer);
      }
      else if(settings === 'share') {
      share(fileName, buffer);
      }
  
  };


  const monthlyExcelFile = async (data, fileName,settings) => {
    // Convert your JSON data to a worksheet
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(fileName);


    const headers = [
      { header: "S.No", key: "sno", width: 6 },
      { header: "Date", key: "date", width: 15 },
      { header: "Department", key: "department", width: 15 },
      { header: "Employee Name", key: "employeeName", width: 20 },
      { header: "Status", key: "status", width: 15 },
      { header: "Count", key: "attendanceCount", width: 15 },
      { header: "Punch In Time", key: "attendancePunchInTime", width: 15 },
      { header: "Punch Out Time", key: "attendancePunchOutTime", width: 15 },
      { header: "DurationHrs", key: "attendanceDurationHrs", width: 15 },
      { header: "DurationMins", key: "attendanceDurationMins", width: 15 },
      { header: "otDurationHrs", key: "otDurationHrs", width: 15 },
      { header: "otDurationMins", key: "otDurationMins", width: 15 },
      { header: "Location", key: "attendanceLocation", width: 25 },


    ];

    worksheet.columns = headers;

    // Make header row bold and increase font size
    worksheet.getRow(1).eachCell((cell) => {
      cell.font = { bold: true, };
    });

    // Format and add each data row
    data.forEach((item, index) => {
      const row = worksheet.addRow({
        sno: index + 1,
        date: formatTOddmmyy(item.date),
        department: item.department,
        employeeName: item.employeeName,
        status: item.status,
        attendanceCount: item.attendanceCount,
        attendancePunchInTime: formatDateTimeFromApiToUITimeOnly(item.attendancePunchInTime),
        attendancePunchOutTime: formatDateTimeFromApiToUITimeOnly(item.attendancePunchOutTime),
        attendanceDurationHrs: item.attendanceDurationHrs,
        attendanceDurationMins: item.attendanceDurationMins,
        otDurationHrs: item.otDurationHrs,
        otDurationMins: item.otDurationMins,
        attendanceLocation: item.attendanceLocation?.[0] 
                ? `${item.attendanceLocation[0].latitude},${item.attendanceLocation[0].longtitude},${item.attendanceLocation[0].address}` 
                : ''
      });

      // Highlight "absent" rows in red
      if (item.status?.toLowerCase() === 'absent') {
        row.eachCell((cell) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'ffcccc' },
          };
        });
      }
      if (item.status?.toLowerCase() === 'leave request pending') {
        row.eachCell((cell) => {
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'ebe16a' },
          };
        });
      }
    
    });

        

    // Generate the file buffer
    const buffer = await workbook.xlsx.writeBuffer();
    if(settings === 'download') {
      download(fileName, buffer);
    }
    else if(settings === 'share') {
    share(fileName, buffer);
    }

};

const download = async (fileName, buffer) => {
  try {
    const base64 = buffer.toString('base64');
    const mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    const tempFileUri = FileSystem.documentDirectory + `${fileName}.xlsx`;

    await FileSystem.writeAsStringAsync(tempFileUri, base64, {
      encoding: FileSystem.EncodingType.Base64,
    });

    if (Platform.OS === 'android') {
      let savedUri = await AsyncStorage.getItem('DIRECTORY_URI');

      // If no saved URI, request permissions
      if (!savedUri) {
        const permissions = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
        if (permissions.granted) {
          savedUri = permissions.directoryUri;
          await AsyncStorage.setItem('DIRECTORY_URI', savedUri); // Save it for next time
        } else {
          Sharing.shareAsync(tempFileUri);
          return;
        }
      }

      try {
        const fileUri = await FileSystem.StorageAccessFramework.createFileAsync(
          savedUri,
          fileName,
          mimeType
        );

        await FileSystem.writeAsStringAsync(fileUri, base64, {
          encoding: FileSystem.EncodingType.Base64,
        });

        Toast.show({
          type: 'success',
          text1: 'File downloaded successfully 📁',
        });
      } catch (e) {
        console.log('SAF Error:', e);
        Toast.show({
          type: 'error',
          text1: 'Failed to save using SAF',
        });
      }
    } else {
      Sharing.shareAsync(tempFileUri);
    }
  } catch (error) {
    console.error("Download error:", error);
    Toast.show({
      type: "error",
      text1: "Failed to download",
    });
  }
};


  const share = async (fileName, buffer) => {

    try {

    // Define a path for saving the file in the device's document directory
    const fileUri = FileSystem.documentDirectory + `${fileName}.xlsx`;
  
    // Write the file to local storage
    await FileSystem.writeAsStringAsync(fileUri,  buffer.toString("base64"), {
      encoding: FileSystem.EncodingType.Base64,
    });

    console.log('Excel file created at:', fileUri);

    // Open the sharing dialog so the user can download or share the file
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(fileUri, {
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        dialogTitle: 'Share your '+fileName,
        UTI: 'com.microsoft.excel.xlsx',
      });
    } else {
      alert('Sharing is not available on this device');
    }
  } catch (error) {
    console.error('Error exporting Excel:', error);
    // Optionally, display a toast or alert to inform the user
  }
}



  useEffect(() => {
    const fetchData = async () => {
      setLoad(true)
      try {
        const response = await getFromAPI("Attendance/GetUserDetails");
        if (response) {
          setUserData(response.data);
        }
      } catch (error) {
        console.error(error);
      } finally {
        setLoad(false)
      }
    };
    fetchData();
  }, []);


  const handleSubmit = async (settings) => {
    ReportType == 1 ? fetchDailyReport(settings) : fetchMonthlyReport(settings)
  }

  
    const fetchDailyReport = async (settings) => {
        setLoad(true);
        try {
          const requestData = {
            fromDate: FromandToformat(fromDate),
          };
          const response = await getFromAPI("/Attendance/DailyAttendaceReport?" + getAPIFormat(requestData));
          console.log(requestData,response)
          if (response && response.data) {
            await dailyExcelFile(response.data, "Daily Attendance Report",settings);
          }          
          
        } catch (error) {
          console.error("Error fetching dashboard data:", error);
        } finally {
          setLoad(false);
        }
      };
      const fetchMonthlyReport = async (settings) => {
        setLoad(true);
        try {
          const requestData = {
                  empId: ReportType==2?0:User,
                  fromDate: FromandToformat(fromDate),
                  toDate: FromandToformat(toDate),
          };
          const response = await getFromAPI("/Attendance/NewMonthlyAttendanceReport?" + getAPIFormat(requestData));
          console.log(requestData,response)
          if (response && response.data) {
            await monthlyExcelFile(response.data,ReportType==2?"Monthly Attendance Report":"User Wise Attendance Report",settings);
          }  
          
        } catch (error) {
          console.error("Error fetching dashboard data:", error);
        } finally {
          setLoad(false);
        }
      };
  

  return (
    <View style={styles.container}>
      <Loader visible={Load} />
    
          <View style={{ marginBottom: 5 }}>
            <DropdownComponent
              data={ReportTypeDD} // API response data
              setSelectdp={(e) => { setReportType(e); }} // Function to update the selected value
              Selectdp={ReportType} // The selected category value
              disabled={false}
              heading="Select Report Type"
              label="Description" // Display field
              value="UID" // Actual value field
            />
          </View>

          {ReportType == 3 && 
          <View style={{ marginBottom: 5 }}>
            <DropdownComponent
              data={UserData} // API response data
              setSelectdp={(e) => { setUser(e); }} // Function to update the selected value
              Selectdp={User} // The selected category value
              disabled={false}
              heading="Select User"
              label="name" // Display field
              value="uId" // Actual value field
            />
          </View>
          }

           

          {/* Time Pickers From Starts */}
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <TouchableOpacity style={[styles.inputContainer, { flex: 1, marginRight: 8 }]} onPress={() => setShowFromTimePicker(true)}>
              <MaterialIcons name="calendar-today" size={24} color="#007bff" />
              <Text style={styles.inputText}>From:</Text>
              <Text style={styles.inputText}>{fromDate.toLocaleDateString()}</Text>
            </TouchableOpacity>


              {showFromTimePicker && (
              <DateTimePicker
                value={fromDate}
                mode="date"
                display="default"
                onChange={(event, selectedDate) => {
                  setShowFromTimePicker(false);
                  if (selectedDate) setFromDate(selectedDate);
                }}
              />
            )}
            
            {ReportType !== 1 && 
            <TouchableOpacity style={[styles.inputContainer, { flex: 1,marginLeft: 8 }]} onPress={() => setShowToTimePicker(true)}>
              <MaterialIcons name="calendar-today" size={24} color="#007bff" />
              <Text style={styles.inputText}>To:</Text>
              <Text style={styles.inputText}>{toDate.toLocaleDateString()}</Text>
            </TouchableOpacity>
            }


            {showToTimePicker && (
              <DateTimePicker
                value={toDate}
                mode="date"
                display="default"
                onChange={(event, selectedDate) => {
                  setShowToTimePicker(false);
                  if (selectedDate) setToDate(selectedDate);
                }}
              />
            )}
          </View>

          <View style={styles.card}>
          <TouchableOpacity style={[styles.backButton, styles.leftButton]} onPress={()=>handleSubmit('download')}>
            <Text style={styles.backText}>Download</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.backButton, styles.rightButton]} onPress={()=>handleSubmit('share')}>
            <Text style={styles.backText}>Share</Text>
          </TouchableOpacity>
        </View>
       
    </View>
  );
};

export default LeaveRequestForm;

const styles = StyleSheet.create({
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1, // ✅ Added border for consistency
    borderColor: "grey", // ✅ Dull Red Border
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },
  

  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Input Text
  },
  
  
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "#f5f5f5",
  },
  
  errorText: {
    color: "red",
    fontSize: 12,
    marginTop: 5,
  },
  backButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: "#007bff",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: 5, // Spacing between buttons
  },
  
  leftButton: {
    backgroundColor: "#007bff",
    borderColor: "#007bff",
  },
  
  rightButton: {
    backgroundColor: "green",
    borderColor: "green",
  },
  
  backText: {
    color: "white",
    fontWeight: "bold",
  },
  
  card: {
    backgroundColor: "#fff",
    padding: 5,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "grey",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 25,
  }
  
});
