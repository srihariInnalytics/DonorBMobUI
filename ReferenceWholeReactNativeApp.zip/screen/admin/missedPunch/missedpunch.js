import { View, Dimensions, Text, FlatList, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import React, { useState, useEffect } from "react";
import DateTimePicker from "@react-native-community/datetimepicker";
import { MaterialIcons } from "@expo/vector-icons";
import { postToAPI, getFromAPI, putToAPI } from '../../../apicall/apicall'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAPIFormat } from '../../../apicall/apifFromats'
import { useAuth } from '../../../auth/AuthContext'
import { formatTOddmmyy, formatDateTimeFromApiToUITimeOnly, DateTimePickerToApiFormat, getCurrDateTime, mergeDateTimeforDatePicker } from '../../../shared/sharedFunctions'
import Loader from '../../../component/loader/Loader'
import Toast from "react-native-toast-message";
import DropdownComponent from '../../../component/dropdown2/DropDown';
import { Dialog, Portal } from "react-native-paper";
import { Button } from "react-native-elements";

const missedpunch = () => {
  const { width, height } = Dimensions.get('window');
  const [Load, setLoad] = useState(false)
  const { user } = useAuth();
  const [MainDataPending, setMainDataPending] = useState([])
  const [MainDataCompleted, setMainDataCompleted] = useState([])
  const [EmployeesDD, setEmployeesDD] = useState([])
  const [Employee, setEmployee] = useState(0)
  const [activeTab, setActiveTab] = useState("Pending"); // "Pending" | "Completed"
  const [Show, setShow] = useState(true); // true to show pending adn false to show completed
  const [PopupVis, setPopupVis] = useState(false);
  const [PopupType, setPopupType] = useState(true); // popup is acept or reject true = acept , false = reject
  const [ActionItem, setActionItem] = useState({});
  const [remarks, setRemarks] = useState('');

  // console.log(Employee, "Employee")
  // console.log("MainDataPending", MainDataPending)
  //   console.log(EmployeesDD,"EmployeesDD")
  // console.log(user, "user from missed punch approval screen")







  const [date1, setDate1] = useState(() => {
    const date = new Date();
    date.setDate(1);
    return date;
  });
  const [date2, setDate2] = useState(new Date());
  const [showFromTimePicker, setShowFromTimePicker] = useState(false);
  const [showToTimePicker, setShowToTimePicker] = useState(false);
  const [remarksError, setRemarksError] = useState("");


  const formatToSqlDate = (date) => {
    const d = new Date(date);
    const day = d.getDate();
    const month = d.getMonth() + 1; // Months are zero-based
    const year = d.getFullYear();
    return `${month}/${day}/${year} 12:00:00 AM`;
  };







  const StatusColor = {
    1: '#FFD700',   // Yellow for Pending
    2: '#28a745',   // Green for Approved
    4: '#FF0000',     // Bright Red for Cancelled
  };

  const filteredData = MainDataPending.filter(d => {
    if (activeTab === "Pending") return d.status === 1;
    if (activeTab === "Approved") return d.status === 3;
    if (activeTab === "Rejected") return d.status === 5;
    return false;
  });

  const handleAccept = async (item, remarks) => {
    try {
      setLoad(true);

      const params = {
        attendanceId: item.attendanceID,
        missedPunchingId: item.uid,
        employeeId: user.login.employee_UID,
        isRequestAccept: 3,
        approveRemarks: remarks, // or dynamic
      };

      const queryString = new URLSearchParams(params).toString();

      const response = await putToAPI(
        `/Attendance/UpdateMissedPunching?${queryString}`,
        {},
        {}
      );

      console.log("Response from API:", response);

      if (response.messageCode === "SUCC001") {
        Toast.show({
          type: "success",
          text1: "Approved",
          text2: "Permission Approved Successfully",
        });
      } else {
        Toast.show({
          type: "error",
          text1: "Something went wrong",
          text2: "Please try again...",
        });
      }
    } catch (e) {
      console.log("Error ", e);
    } finally {
      setLoad(false);
      handleEmployeeChange()
      setPopupVis(false);
    }
  };

  const handleReject = async (item) => {
    try {
      setLoad(true)
      const params = {
        attendanceId: item.attendanceID,
        missedPunchingId: item.uid,
        employeeId: user.login.employee_UID,
        isRequestAccept: 5,
        approveRemarks: remarks, // or dynamic
      };

      const queryString = new URLSearchParams(params).toString();

      const response = await putToAPI(
        `/Attendance/UpdateMissedPunching?${queryString}`,
        {},
        {}
      );

      console.log("Response from API:", response);

      if (response.messageCode == "SUCC001") {
        Toast.show({
          type: "success",
          text1: "Rejected",
          text2: "Permission Rejected Successfully",
        });
      }
      else {
        Toast.show({
          type: "error",
          text1: "Something went wrong",
          text2: "Please try again...",
        });
      }
    }
    catch (e) {
      console.log("Eror ", e)
    }
    finally {
      setLoad(false)
      handleEmployeeChange()
      setPopupVis(false)
    }
  };





  const fetchDataInitial1 = async () => {
    try {
      setLoad(true)


      const [res1] = await Promise.all([
        getFromAPI('/Attendance/GetUserDetails'), //  5


      ]);
      setEmployeesDD(res1.data)

    } catch (e) {
      console.error("❌ Error from Missed punch approval", e);
    } finally {
      setLoad(false)
    }
  };

  useEffect(() => {
    fetchDataInitial1() //initial api cal for Pending
  }, [])

  const handleEmployeeChange = async (empId) => {
    try {
      setLoad(true)
      const DataToAPI1 = {

        empId: Employee,
        loggedInUser: user.login.employee_UID,
        // loggedInUser:1000146, // for testing purpose
        FromDate: formatToSqlDate(date1), // date1,
        ToDate: formatToSqlDate(date2),


      };

      // console.log("DataToAPI11111111111111", DataToAPI1)

      const [res1] = await Promise.all([
        getFromAPI('/Attendance/Admin/GetMissedPunchingsByDate?' + getAPIFormat(DataToAPI1))
      ]);



      setMainDataPending(res1.data);
    } catch (e) {
      console.error("❌ Error from Permission Request123:", e);
    } finally {
      setLoad(false);
    }
  };

  useEffect(() => {
    handleEmployeeChange()
  }, [date1, date2]); // Re-fetch data when date1, date2 or Employee changes





  return (
    <View style={styles.container}>

      <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginBottom: 10 }}>
        {["Pending", "Approved", "Rejected"].map((tab) => (
          <TouchableOpacity
            key={tab}
            style={{
              padding: 10,
              borderBottomWidth: activeTab === tab ? 2 : 0,
              borderBottomColor: '#007bff'
            }}
            onPress={() => {
              console.log("Tab pressed:", tab);
              setActiveTab(tab);
              handleEmployeeChange(Employee); // re-fetch with new filter
            }}
          >
            <Text style={{ color: activeTab === tab ? '#007bff' : '#888' }}>{tab}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 10 }}>
        <TouchableOpacity
          style={[styles.inputContainer, { flex: 1, marginRight: 5, marginTop: 10 }]}
          onPress={() => setShowFromTimePicker(true)}
        >
          <MaterialIcons name="calendar-today" size={24} color="#007bff" />
          <View>

            <Text style={styles.inputText}>From: {formatTOddmmyy(date1)}</Text>

          </View>
        </TouchableOpacity>

        {showFromTimePicker && (
          <DateTimePicker
            value={date1}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              setShowFromTimePicker(false);
              if (selectedDate) setDate1(selectedDate);
            }}
          />
        )}

        {/* To Date Picker */}
        <TouchableOpacity
          style={[styles.inputContainer, { flex: 1, marginHorizontal: 5, marginTop: 10 }]}
          onPress={() => setShowToTimePicker(true)}
        >
          <MaterialIcons name="calendar-today" size={24} color="#007bff" />
          <View>
            <Text style={styles.inputText}>To: {formatTOddmmyy(date2)}</Text>

          </View>
        </TouchableOpacity>

        {showToTimePicker && (
          <DateTimePicker
            value={date2}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              setShowToTimePicker(false);
              if (selectedDate) setDate2(selectedDate);
            }}
          />
        )}
      </View>


      <View style={{ marginBottom: 5 }}>
        <DropdownComponent
          data={EmployeesDD} // API response data
          // setSelectdp={handleEmployeeChange}
          setSelectdp={(e) => {
            setEmployee(e);
            handleEmployeeChange(e); // 👈 Pass the new value directly
          }}
          Selectdp={Employee}
          disabled={false}
          heading="Select Employee"
          label="name" // Display field
          value="uId" // Actual value field
        />
      </View>





      <Loader visible={Load} />
      {Show ?
        <>
          {MainDataPending.length == 0 &&
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
              <MaterialIcons name="inbox" size={Math.min(width, height) * 0.4} color="#ccc" />
              <Text style={{ marginTop: 20, fontSize: 18, color: '#888' }}>There is no data</Text>
            </View>}

          <FlatList
            data={filteredData}
            keyExtractor={(item) => item.uid}
            renderItem={({ item }) => (
              <View style={styles.card}>

                <View style={styles.row}>
                  <Text style={styles.label}>Date:</Text>
                  <Text style={styles.value}>{formatTOddmmyy(item.date)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>In Time:</Text>
                  <Text style={styles.value}>{formatDateTimeFromApiToUITimeOnly(item.fromTime)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Out Time:</Text>
                  <Text style={styles.value}>{formatDateTimeFromApiToUITimeOnly(item.toTime)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Employee Name:</Text>
                  <Text style={styles.value}>{item.name}</Text>
                </View>





                <View style={styles.row}>
                  <Text style={styles.label}>Designation:</Text>
                  <Text style={styles.value}>{item.designation}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Department:</Text>
                  <Text style={styles.value}>{item.department}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Location:</Text>
                  <Text style={styles.value}>{item.location}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Remarks:</Text>
                  <Text style={styles.value}>{item.remark}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Created Date:</Text>
                  <Text style={styles.value}>{formatTOddmmyy(item.createdDate)}</Text>
                </View>





                <View style={styles.row}>
                  <Text style={styles.label}>Status:</Text>
                  <Text
                    style={[
                      styles.status,
                      item.status !== 5 && { color: StatusColor[item.status] } // No color for Rejected
                    ]}
                  >
                    {item.status === 3 && "Approved" ||
                      item.status === 4 && "Cancelled" ||
                      item.status === 5 && "Rejected" ||
                      item.status === 1 && "Pending"}
                  </Text>
                </View>

                {activeTab === "Pending" && (
                  <View style={{ flexDirection: "row", justifyContent: " space-between", gap: 2 }}>
                  <TouchableOpacity style={styles.AcceptButton} onPress={() => { setActionItem(item); setPopupType(true); setPopupVis(true) }}>
                    <Text style={styles.buttonTextAccept}>Accept</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.RejectButton} onPress={() => { setActionItem(item); setPopupType(false); setPopupVis(true) }}>
                    <Text style={styles.buttonTextReject}>Reject</Text>
                  </TouchableOpacity>
                </View>
                )}
              </View>
            )}
          />

          {/* popup  starts ---- */}
          <Portal>
            <Dialog visible={PopupVis} onDismiss={() => setPopupVis(false)}>
              <Dialog.Title>Approval Confirmation</Dialog.Title>
              <TextInput
                style={styles.input1}
                placeholder="Remarks"
                value={remarks}
                onChangeText={(text) => {
                  setRemarks(text);
                  if (text.trim()) setRemarksError(""); // Clear error on valid input
                }} />

              {remarksError ? (
                <Text style={{ color: 'red', marginLeft: 10 }}>{remarksError}</Text>
              ) : null}
              <Dialog.Content>
                {PopupType ?
                  <Text>Are you sure you want to Accept this?</Text>
                  :
                  <Text>Are you sure you want to Reject this?</Text>
                }
              </Dialog.Content>
              <Dialog.Actions style={{ flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 10 }}>
                <Button
                  title="Yes"
                  buttonStyle={{ backgroundColor: "green", width: "80%" }}
                  onPress={() => {
                    if (!remarks.trim()) {
                      setRemarksError("Remarks are required");
                      return;
                    }
                    if (PopupType) {
                      handleAccept(ActionItem, remarks)

                    }
                    else {
                      handleReject(ActionItem, remarks)

                    }
                    setActionItem({});
                    setRemarks("");
                    setPopupVis(false);
                  }
                  }
                />
                <Button
                  title="No"
                  buttonStyle={{ backgroundColor: "red", width: "80%" }}
                  onPress={() => setPopupVis(false)}
                />
              </Dialog.Actions>
            </Dialog>
          </Portal>
          {/* popup  ends ---- */}
        </> :
        <>
          {MainDataCompleted.length == 0 &&
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
              <MaterialIcons name="inbox" size={Math.min(width, height) * 0.4} color="#ccc" />
              <Text style={{ marginTop: 20, fontSize: 18, color: '#888' }}>There is no data</Text>
            </View>}
          <FlatList
            data={MainDataCompleted}
            keyExtractor={(item) => item.uid}
            renderItem={({ item }) => (
              <View style={styles.card}>

                <View style={styles.row}>
                  <Text style={styles.label}>Name:</Text>
                  <Text style={styles.value}>{item.employee}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Date:</Text>
                  <Text style={styles.value}>{formatTOddmmyy(item.fromDate)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>From Time:</Text>
                  <Text style={styles.value}>{formatDateTimeFromApiToUITimeOnly(item.fromDate)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>To Time:</Text>
                  <Text style={styles.value}>{formatDateTimeFromApiToUITimeOnly(item.toDate)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Reason:</Text>
                  <Text style={styles.value}>{item.remark}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Created Date:</Text>
                  <Text style={styles.value}>{formatTOddmmyy(item.createdDate)}</Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Status:</Text>
                  <Text
                    style={[
                      styles.status,
                      item.status !== 3 && { color: StatusColor[item.status] } // No color for Rejected
                    ]}
                  >
                    {item.status === 3 && "Approved" ||
                      item.status === 4 && "Cancelled" ||
                      item.status === 5 && "Rejected" ||
                      item.status === 1 && "Pending"}
                  </Text>
                </View>

                <View style={styles.row}>
                  <Text style={styles.label}>Modified By:</Text>
                  <Text style={styles.value}>
                    {item.modifiedBy}
                  </Text>
                </View>

              </View>
            )}
          />
        </>
      }
    </View>
  )
}

export default missedpunch

const styles = StyleSheet.create({
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    justifyContent: "center",
    borderWidth: 1, // ✅ Added border for consistency
    borderColor: "grey", // ✅ Dull Red Border
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },
  timeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  timeBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    flex: 1,
    justifyContent: "center",
    marginRight: 5,
    borderWidth: 1, // ✅ Added border
    borderColor: "black", // ✅ Dull Red Border
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Input Text
  },
  submitButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
  },
  showFormButton: {
    backgroundColor: "#D32F2F", // ✅ Dull Red Show Form Button
    padding: 12,
    alignItems: "center",
    borderRadius: 5,
    marginBottom: 10,
  },
  submitText: {
    color: "#D32F2F",
    fontWeight: "bold",
  },
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "#f5f5f5",
  },
  card: {
    backgroundColor: "#FFF",
    padding: 20,
    borderRadius: 10,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
    padding: 5
  },
  label: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
    color: "black",
  },
  value: {
    fontSize: 18, // Increased font size
    color: "#333",
  },
  status: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
  },
  floatingButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    width: 70, // Increased size
    height: 70,
    borderRadius: 35,
    backgroundColor: "#D32F2F",
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  AcceptButton: {
    flex: 1,
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#28a745",  // ✅ Outline color
    alignItems: "center"
  },
  RejectButton: {
    flex: 1,
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
    alignItems: "center"
  },
  buttonTextAccept: {
    color: "#28a745",  // ✅ Same color as border
    fontSize: 18,
    fontWeight: "bold",

  },
  buttonTextReject: {
    color: "#D32F2F",  // ✅ Same color as border
    fontSize: 18,
    fontWeight: "bold",
  },
  errorText: {
    color: "red",
    fontSize: 12,
    marginTop: 5,
  },
  backText: {
    color: "#007bff",
    fontWeight: "bold",
  },
  backButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#007bff",  // ✅ Outline color
  },

  tabContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 10,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 10,
    backgroundColor: "#f0f0f0",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ccc",
  },
  activeTab: {
    backgroundColor: "#D0E8FF", // Your theme green
  },
  tabText: {
    color: "black",
    fontWeight: "bold",
  },
  input1: { borderWidth: 1, borderColor: '#ccc', borderRadius: 5, padding: 10, marginBottom: 10 },


});