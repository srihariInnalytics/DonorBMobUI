import React, { useState, useEffect } from "react";
import { View, Dimensions, Text, FlatList, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import { MaterialIcons } from "@expo/vector-icons";
import { postToAPI, getFromAPI } from '../../apicall/apicall'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAPIFormat } from '../../apicall/apifFromats'
import { useAuth } from '../../auth/AuthContext'
import { formatTOddmmyy, formatDateTimeFromApiToUITimeOnly, DateTimePickerToApiFormat, getCurrDateTime, mergeDateTimeforDatePicker } from '../../shared/sharedFunctions'
import Loader from '../../component/loader/Loader'

const AttendanceScreen = () => {
  const { width, height } = Dimensions.get('window');
  const [Load, setLoad] = useState(false)
  const [date1, setDate1] = useState(new Date()); // for leave date
  const [date2, setDate2] = useState(new Date()); // for leave date
  const [showDatePicker1, setShowDatePicker1] = useState(false);
  const [showDatePicker2, setShowDatePicker2] = useState(false);
  const { user } = useAuth();
  const [MainData, setMainData] = useState([])

  const fetchData = async () => {
    try {
      setLoad(true)
      // console.log("USERDATA -- 1" , user )
      const DataToAPI1 = {
        fromDate: date1.toISOString(),
        toDate: date2.toISOString(),
        empId: user.login.employee_UID
      };
      console.log("🔹 Data to api", DataToAPI1)
      console.log("🔹 Data to api", getAPIFormat(DataToAPI1))
      const [res1] = await Promise.all([
        getFromAPI('/Attendance/AttendanceReport?' + getAPIFormat(DataToAPI1)), //  5
      ]);
      setMainData(res1.data)
      console.log("✅ Response From Api - 0000  :", res1);
    } catch (e) {
      console.error("❌ Error from Initial Request:", e);
    } finally {
      setLoad(false)
    }
  };

  const fetchDataAfterSelection = async (d1, d2) => {
    try {
      setLoad(true)
      const DataToAPI1 = {
        fromDate: d1.toISOString(),
        toDate: d2.toISOString(),
        empId: user.login.employee_UID
      };
      console.log("🔹 Data to api", DataToAPI1)
      console.log("🔹 Data to api", getAPIFormat(DataToAPI1))
      const [res1] = await Promise.all([
        getFromAPI('/Attendance/AttendanceReport?' + getAPIFormat(DataToAPI1)), //  5
      ]);
      setMainData(res1.data)
      console.log("✅ Response From Api - 0000  :", res1);
    } catch (e) {
      console.error("❌ Error from Initial Request:", e);
    } finally {
      setLoad(false)
    }
  };

  useEffect(() => {
    fetchData()
  }, [])

  return (
    <View style={styles.container}>
      <Loader visible={Load} />

      {/* ------------- */}
      <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 1, marginBottom: 3 }}>
        <TouchableOpacity style={{ flexDirection: "row", alignItems: "center", backgroundColor: "#fff", padding: 10, borderRadius: 8, flex: 1, marginRight: 8 }} onPress={() => setShowDatePicker1(true)}>
          <MaterialIcons name="calendar-today" size={24} color="#007bff" />
          <Text style={styles.inputText}>From Date : </Text>
          <Text style={styles.inputText}>{date1.toLocaleDateString()}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={{ flexDirection: "row", alignItems: "center", backgroundColor: "#fff", padding: 10, borderRadius: 8, flex: 1, marginRight: 8 }} onPress={() => setShowDatePicker2(true)}>
          <MaterialIcons name="calendar-today" size={24} color="#007bff" />
          <Text style={styles.inputText}>To Date : </Text>
          <Text style={styles.inputText}>{date2.toLocaleDateString()}</Text>
        </TouchableOpacity>
      </View>

      {showDatePicker1 && (
        <DateTimePicker
          value={date1}
          mode="date"
          display="default"
          onChange={(event, selectedDate) => {
            // console.log("EVENT CHANGED ", selectedDate)
            setShowDatePicker1(false);
            // console.log("SELECTED DATE", selectedDate)
            if (selectedDate) setDate1(selectedDate);
            fetchDataAfterSelection(selectedDate, date2)
          }}
        />
      )}

      {showDatePicker2 && (
        <DateTimePicker
          value={date2}
          mode="date"
          display="default"
          onChange={(event, selectedDate) => {
            // console.log("EVENT CHANGED ", selectedDate)
            setShowDatePicker2(false);
            // console.log("SELECTED DATE", selectedDate)
            if (selectedDate) setDate2(selectedDate);
            fetchDataAfterSelection(date1, selectedDate)
          }}
        />
      )}
      {/* ------------- */}
      {MainData.length == 0 &&
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
          <MaterialIcons name="inbox" size={Math.min(width, height) * 0.4} color="#ccc" />
          <Text style={{ marginTop: 20, fontSize: 18, color: '#888' }}>There is no data</Text>
        </View>}
      <FlatList
        data={MainData}
        keyExtractor={(item) => item.uid}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.row}>
              <Text style={styles.label}>Name : </Text>
              <Text style={styles.value}> {item.name}</Text>
            </View>

            <View style={styles.row}>
              <Text style={styles.label}>Designation : </Text>
              <Text style={styles.value}> {item.designation}</Text>
            </View>

            <View style={{ flexDirection: "row", alignItems: 'center', justifyContent: "space-between", gap: 0 }}>
              <View style={styles.row}>
                <Text style={styles.label}>Date : </Text>
                <Text style={styles.value}> {formatTOddmmyy(item.date)}</Text>
              </View>

              <View style={styles.row}>
                <Text style={styles.label}>Working Hours : </Text>
                <Text style={styles.value}> {item.workingHrs}</Text>
              </View>
            </View>

            <View style={{ flexDirection: "row", alignItems: 'center', justifyContent: "space-between", gap: 0 }}>
              <View style={[styles.row]}>
                <Text style={styles.label}>Punch In : </Text>
                <Text style={[styles.value, { color: "green" }]}> {formatDateTimeFromApiToUITimeOnly(item.punchInTime)}</Text>
              </View>

              <View style={[styles.row]}>
                <Text style={styles.label}>Punch Out : </Text>
                <Text style={[styles.value, { color: "red" }]}> {formatDateTimeFromApiToUITimeOnly(item.punchOutTime)}</Text>
              </View>
            </View>

            <View style={styles.row}>
              <Text style={styles.label}>Remarks : </Text>
              <Text style={styles.value}> {item.remark}</Text>
            </View>

          </View>
        )}
      />


    </View>
  );
};

export default AttendanceScreen;

const styles = StyleSheet.create({
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1, // ✅ Added border for consistency
    borderColor: "black", // ✅ Dull Red Border
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },
  timeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  timeBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    flex: 1,
    justifyContent: "center",
    marginRight: 5,
    borderWidth: 1, // ✅ Added border
    borderColor: "black", // ✅ Dull Red Border
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Input Text
  },
  submitButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
  },
  showFormButton: {
    backgroundColor: "#D32F2F", // ✅ Dull Red Show Form Button
    padding: 12,
    alignItems: "center",
    borderRadius: 5,
    marginBottom: 10,
  },
  submitText: {
    color: "#D32F2F",
    fontWeight: "bold",
  },
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "#f5f5f5",
  },
  card: {
    backgroundColor: "#FFF",
    padding: 20,
    borderRadius: 10,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  row: {
    flexDirection: "row",
    // justifyContent: "space-between",
    alignItems: 'center',
    marginBottom: 8,
    padding: 5
  },
  label: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
    color: "black",
  },
  value: {
    fontSize: 18, // Increased font size
    color: "#333",
  },
  status: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
  },
  floatingButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    width: 70, // Increased size
    height: 70,
    borderRadius: 35,
    backgroundColor: "#D32F2F",
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  cancelButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
  },
  buttonText: {
    color: "#D32F2F",  // ✅ Same color as border
    fontSize: 18,
    fontWeight: "bold",
  },
  errorText: {
    color: "red",
    fontSize: 12,
    marginTop: 5,
  },
  backText: {
    color: "#007bff",
    fontWeight: "bold",
  },
  backButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#007bff",  // ✅ Outline color
  },
});
