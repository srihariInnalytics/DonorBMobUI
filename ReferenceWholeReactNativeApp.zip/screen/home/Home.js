import React, { useState, useRef, useLayoutEffect } from "react";
import { View, Text, StyleSheet, Dimensions, TouchableOpacity,Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { colors as colorss } from "../../component/config/config";
import { Menu, IconButton, Drawer } from "react-native-paper";
import { useAuth } from "../../auth/AuthContext";
import DrawerLayout from "react-native-gesture-handler/DrawerLayout"; // ✅ Import DrawerLayout
import { MaterialIcons } from "@expo/vector-icons";
import Servicecallbooking from '../ServiceCallbooking/Servicecallbooking';
import LeaveRequest from '../leaverequest/Leaverequest';
import Permissionrequest from '../Permission request/Permissionrequest';
import Dashboard from '../Dashboard/dashboard';
import AttendanceReport from '../Attendance Report/Attendancereport';
import Attendance from '../attendance/Attendance';
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import Ionicons from "react-native-vector-icons/Ionicons";
import Feather from "react-native-vector-icons/Feather";
import AdminAttendanceReport from "../admin/attendanceReport/AtendanceReport";
import LeaveApproval from "../admin/leaveApproval/leaveApproval";
import LeaveReport from "../admin/leaveReport/leaveReport";
import MissedPunch from "../admin/missedPunch/missedpunch";
import PermissionApproval from "../admin/permissionApproval/permissionApproval";


const SCREEN_WIDTH = Dimensions.get("window").width; // Get screen width

const HomeScreen = () => {
  const navigation = useNavigation();
  const { user, logout } = useAuth();
  const drawerRef = useRef(null); // ✅ Reference for the Drawer
  const [menuVisible, setMenuVisible] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false); // State to track drawer open/close
  const menus = {
    dashboard: "Dashboard",
    attendance: "Attendance",
    leaveRequest: "Leave Request",
    permissionRequest: "Permission Request",
    attendanceReport: "Attendance Report",
    AdminAttendanceReport: "Admin Attendance Report",
    leaveApproval: "Leave Approval",
    leaveReport: "Leave Report",
    missedPunch: "Missed Punch",
    permissionApproval: "Permission Approval",

  }
  const [active, setActive] = useState(menus.dashboard); // State to track active menu item




  const handleLogout = async () => {
    setMenuVisible(false);
    logout();
    navigation.reset({
      index: 0,
      routes: [{ name: "Login" }],
    });
  };

  const toggleDrawer = () => {
    if (isDrawerOpen) {
      drawerRef.current.closeDrawer();
    } else {
      drawerRef.current.openDrawer();
    }
    setIsDrawerOpen(!isDrawerOpen);
  };


  const renderDrawer = () => (
    <View style={styles.drawerContainer}>

      <Drawer.Section>
        <TouchableOpacity
          style={styles.row}
          onPress={() => navigation.navigate("Profile")}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <MaterialIcons name="account-circle" size={40} color={'#ec4242'} />
            <View style={{ flexDirection: 'column' }}>
              <Text style={{ color: colorss.textDark, fontWeight: 'bold' }}>{user.userName}</Text>
              <Text style={{ color: colorss.textDark, }}>UID: {user.login.employee_UID}</Text>
            </View>
          </View>
          <MaterialIcons name="arrow-forward" size={25} color="grey" />
        </TouchableOpacity>
      </Drawer.Section>

      {user.login.app_RollUID == 108 &&
        <Drawer.Section title="Admin Menu" style={{ color: colorss.textDark, fontWeight: 'bold' }}>

          <Drawer.Item
            icon={() => <FontAwesome5 name="calendar-check" size={25} color="#FF9800" />}
            label="Leave Approval"
            active={active === menus.leaveApproval}
            onPress={() => {
              toggleDrawer();
              setActive(menus.leaveApproval);
            }}
          />

          <Drawer.Item
            icon={() => <Ionicons name="clipboard-outline" size={25} color="#007BFF" />}
            label="Permission Approval"
            active={active === menus.permissionApproval}
            onPress={() => {
              toggleDrawer();
              setActive(menus.permissionApproval);
            }}
          />

          <Drawer.Item
            icon={() => <Ionicons name="finger-print-outline" size={25} color="#000000" />}
            label="Missed Punch Approval"
            active={active === menus.missedPunch}
            onPress={() => {
              toggleDrawer();
              setActive(menus.missedPunch);
            }}
          />

          <Drawer.Item
            icon={() => <MaterialIcons name="access-time" size={25} color="#E91E63" />}
            label="Admin Attendance Report"
            active={active === menus.AdminAttendanceReport}
            onPress={() => {
              toggleDrawer();
              setActive(menus.AdminAttendanceReport);
            }}
          />

          <Drawer.Item
            icon={() => <Feather name="file" size={25} color="#28A745" />}
            label="Leave Report"
            active={active === menus.leaveReport}
            onPress={() => {
              toggleDrawer();
              setActive(menus.leaveReport);
            }}
          />
          {/* <Drawer.Item
            icon={() => <Feather name="bar-chart" size={25} color="#9C27B0" />}
            label="Missed Punch"
            active={active === menus.missedPunch}
            onPress={() => {
              toggleDrawer();
              setActive(menus.missedPunch);
            }}
          /> */}
        </Drawer.Section>
      }

      <Drawer.Section>
        <Drawer.Item
          icon={() => <MaterialIcons name="dashboard" size={25} color="#28A745" />}
          label="Dashboard"
          active={active === menus.dashboard}
          onPress={() => {
            toggleDrawer();
            setActive(menus.dashboard);
          }}
        />

        <Drawer.Item
          icon={() => <FontAwesome5 name="calendar-check" size={25} color="#FF9800" />}
          label="Attendance"
          active={active === menus.attendance}
          onPress={() => {
            toggleDrawer();
            setActive(menus.attendance);
          }}
        />

        <Drawer.Item
          icon={() => <Ionicons name="clipboard-outline" size={25} color="#007BFF" />}
          label="Leave Request"
          active={active === menus.leaveRequest}
          onPress={() => {
            toggleDrawer();
            setActive(menus.leaveRequest);
          }}
        />

        <Drawer.Item
          icon={() => <MaterialIcons name="access-time" size={25} color="#E91E63" />}
          label="Permission Request"
          active={active === menus.permissionRequest}
          onPress={() => {
            toggleDrawer();
            setActive(menus.permissionRequest);
          }}
        />

        <Drawer.Item
          icon={() => <Feather name="bar-chart" size={25} color="#9C27B0" />}
          label="Attendance Report"
          active={active === menus.attendanceReport}
          onPress={() => {
            toggleDrawer();
            setActive(menus.attendanceReport);
          }}
        />
      </Drawer.Section>
    </View>
  );

  useLayoutEffect(() => {
    navigation.setOptions({
      headerTitle: () => (
        <View style={styles.headerContainer}>
          <IconButton
            icon="menu"
            iconColor={colorss.textDark}
            onPress={toggleDrawer} // ✅ Opens drawer
            style={styles.menuButton}
          />
      <Image source={require('../../assets/iec_logo.png')} style={styles.logo} />
      </View>
      ),
      headerStyle: { backgroundColor: colorss.header },
      headerRight: () => (
        <View key={menuVisible.toString()} style={styles.headerRight}>
          <Text style={{ color: colorss.textDark, fontWeight: 'bold' }}>{user.userName}</Text>
          <Menu
            visible={menuVisible}
            onDismiss={() => setMenuVisible(false)}
            anchor={
              <IconButton
                icon="account-circle"
                iconColor={colorss.textDark}
                onPress={() => setMenuVisible(true)}
              />
            }
          >
          </Menu>
        </View>
      ),
    });
  }, [navigation, menuVisible, isDrawerOpen]); // ✅ Add menuVisible as dependency

  return (
    <DrawerLayout
      ref={drawerRef}
      drawerWidth={SCREEN_WIDTH * 0.7} // Set the width of the drawer
      drawerPosition="left"
      renderNavigationView={renderDrawer}
      onDrawerClose={() => setIsDrawerOpen(false)}
    >
      <View style={styles.container}>
        {
          active === menus.dashboard ? <Dashboard /> :
            active === menus.attendance ? <Attendance /> :
              active === menus.leaveRequest ? <LeaveRequest /> :
                active === menus.permissionRequest ? <Permissionrequest /> :
                  active === menus.attendanceReport ? <AttendanceReport /> :
                    active === menus.leaveApproval ? <LeaveApproval /> :
                      active === menus.permissionApproval ? <PermissionApproval /> :
                        active === menus.AdminAttendanceReport ? <AdminAttendanceReport /> :
                          active === menus.leaveReport ? <LeaveReport /> :
                            active === menus.missedPunch ? <MissedPunch /> : null

        }
      </View>
    </DrawerLayout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  headerContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerTitle: {
    color: colorss.textDark,
    fontWeight: "bold",
    fontSize: 16,
    marginLeft: 10,
  },
  menuButton: {
    marginLeft: -10,
  },
  drawerContainer: {
    flex: 1,
    backgroundColor: "#fcf9f9",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between", // Ensures proper spacing
    padding: 15,
  },
  logo: {
    width: 100,
    height: 40,
    resizeMode: 'contain',
  },

});

export default HomeScreen; 