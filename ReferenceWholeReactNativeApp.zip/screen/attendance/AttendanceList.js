import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet,FlatList,ScrollView } from 'react-native';
import { getFromAPI, putToAPI, postToAPI } from '../../apicall/apicall';
import { useNavigation } from '@react-navigation/native';
import { formatDateTimeFromApiToUITimeOnly, FromandToformat,getDay,getMonth } from "../../shared/sharedFunctions";
import { useAuth } from "../../auth/AuthContext";
import { Card,Checkbox } from "react-native-paper";
import DateTimePicker from "@react-native-community/datetimepicker";
import Loader from '../../component/loader/Loader'
import { MaterialIcons } from "@expo/vector-icons";
import { getAPIFormat } from "../../apicall/apifFromats";



const AttendanceList = () => {
  const [fromDate, setFromDate] = useState(() => {
      const date = new Date();
      date.setDate(1); 
      return date;
    });  
  const [toDate, setToDate] = useState(() => {
    const date = new Date();
    date.setDate(1); 
    return date;
  }); 
  const [showFromTimePicker, setShowFromTimePicker] = useState(false);
  const [showToTimePicker, setShowToTimePicker] = useState(false);
  const [needOT, setNeedOT] = useState(false);
  const [Load, setLoad] = useState(false)
  const [MainData, setMainData] = useState([]);
  const { user } = useAuth();



  const fetchData = async () => {
      setLoad(true)
      try {
        const requestData = {
          EmployeeId: user.login.employee_UID,
          start: FromandToformat(fromDate),
          end: FromandToformat(toDate),
          rollId:user.login.rollUID,
          needOT:needOT
        };
        const response = await getFromAPI("/Attendance/Admin/GetAllAttendanceByUser?" + getAPIFormat(requestData));
        console.log(requestData,response)
        setMainData(response.data);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoad(false);
      }
    };
  
    useEffect(() => {
      fetchData();
    }, [fromDate,toDate,needOT]);


     const AttendanceCard = ({ item }) => (
          <Card style={styles.card}>
            <View style={styles.cardRow}>
              {/* Date Container */}
              <View style={styles.dateContainer}>
              <Text style={styles.dateText}>{getMonth(item.date)}</Text>
                <Text style={styles.dateText}>{getDay(item.date)}</Text>
              </View>
        
              {/* Details Container */}
              <View style={styles.detailsContainer}>
                  <View style={styles.cardContent}>
                    <View>
                      <Text style={styles.officeText}>
                        {item.location} ({item.totalHours} Hrs)
                      </Text>
                      <Text style={styles.timeText}>
                        {formatDateTimeFromApiToUITimeOnly(item.punchInTime)} - {formatDateTimeFromApiToUITimeOnly(item.punchOutTime)}
                      </Text>
                    </View>
                    
                  </View>
                
              </View>
            </View>
          </Card>
        );


  return (
    <View style={styles.container}>
      <Loader visible={Load} />

      {/* Filters */}
      <View style={{flexDirection: "row", alignItems: "center",padding:5 }}>
        {/* From Date Picker */}
        <TouchableOpacity
          style={[styles.inputContainer, { flex: 1, marginRight: 5, marginTop: 10 }]}
          onPress={() => setShowFromTimePicker(true)}
        >
          <MaterialIcons name="calendar-today" size={24} color="#007bff" />
          <View>
            <Text style={styles.inputText}>From:</Text>
            <Text style={styles.inputText}>{fromDate.toLocaleDateString()}</Text>
          </View>
        </TouchableOpacity>

        {showFromTimePicker && (
          <DateTimePicker
            value={fromDate}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              setShowFromTimePicker(false);
              if (selectedDate) setFromDate(selectedDate);
            }}
          />
        )}

        {/* To Date Picker */}
        <TouchableOpacity
          style={[styles.inputContainer, { flex: 1, marginHorizontal: 5, marginTop: 10 }]}
          onPress={() => setShowToTimePicker(true)}
        >
          <MaterialIcons name="calendar-today" size={24} color="#007bff" />
          <View>
            <Text style={styles.inputText}>To:</Text>
            <Text style={styles.inputText}>{toDate.toLocaleDateString()}</Text>
          </View>
        </TouchableOpacity>

        {showToTimePicker && (
          <DateTimePicker
            value={toDate}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              setShowToTimePicker(false);
              if (selectedDate) setToDate(selectedDate);
            }}
          />
        )}

        
      </View>

      <View>
          <TouchableOpacity 
                  style={{flexDirection: "row", alignItems: "center", padding: 5,}} 
                  onPress={() => setNeedOT(!needOT)}>
          <Checkbox status={needOT ? 'checked' : 'unchecked'} />
            <Text style={{marginLeft: 8,fontSize:16}}>Need OT</Text>

          </TouchableOpacity>
      </View>
      


       <FlatList
            data={MainData}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => <AttendanceCard item={item} />}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
                  <Text style={{ textAlign: "center", marginTop: 20, color: "red" }}>No data available</Text>
              }
            />
      </View>
  )
}

export default AttendanceList

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f9f9f9",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 5,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1, // ✅ Added border for consistency
    borderColor: "grey", // ✅ Dull Red Border
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },

  card: {
    marginVertical: 8,
    padding: 15,
    borderRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  absentCard: {
    backgroundColor: "#f8d7da",
  },
  cardRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  dateContainer: {
    backgroundColor: "#007bff",
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  dateText: {
    color: "white",
    fontWeight: "bold",
  },
  detailsContainer: {
    flex: 1, // Takes up the remaining space
    marginLeft: 10,
  },
  cardContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  officeText: {
    fontSize: 16,
  },
  timeText: {
    fontSize: 14,
    color: "gray",
  },
  dailyText: {
    color: "red",
    fontWeight: "bold",
  },

})