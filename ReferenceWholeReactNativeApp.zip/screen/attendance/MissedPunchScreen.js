import React, { useState, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, Modal, StyleSheet,
  ActivityIndicator, TextInput, FlatList, Platform, SafeAreaView
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { MaterialIcons } from "@expo/vector-icons";
import { getFromAPI, postToAPI, putToAPI } from '../../apicall/apicall';
import { Picker } from '@react-native-picker/picker';
import { formatTOddmmyy, formatDateTimeFromApiToUITimeOnly, mergeDateTimeforDatePicker, DateTimePickerToApiFormat } from '../../shared/sharedFunctions'
import Dropdown from '../../component/dropdown2/DropDown';
import { useAuth } from "../../auth/AuthContext";
import Loader from '../../component/loader/Loader'
import Toast from "react-native-toast-message";
import { getAPIFormat } from '../../apicall/apifFromats';


const MissedPunchScreen = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [chosenLocation, setChosenLocation] = useState('');
  const [MainData, setMainData] = useState([])
  const [date, setDate] = useState(new Date()); // for leave date
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [punchData, setPunchData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState('Office');
  const [missedPunchType, setMissedPunchType] = useState('Punch In');
  const [remarks, setRemarks] = useState('');
  const [time, setTime] = useState('');
  const [FromTimeDateAPI, setFromTimeDateAPI] = useState(DateTimePickerToApiFormat(new Date()));
  const [ToTimeDateAPI, setToTimeDateAPI] = useState(DateTimePickerToApiFormat(new Date()));
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [locations, setLocations] = useState([]);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [fromTime, setFromTime] = useState(null);
  const [toTime, setToTime] = useState(null);
  const [showFromTimePicker, setShowFromTimePicker] = useState(false);
  const [showToTimePicker, setShowToTimePicker] = useState(false);
  const { user } = useAuth();





  const missedPunchOptions = ['Punch In'];
  const StatusColor = {
    1: '#FFD700',   // Yellow for Pending
    11: '#FF0000',     // Bright Red for Cancelled
  };
  const StatusMessage = {
    1: 'Pending',   // Yellow for Pending
    11: 'Cancelled',     // Bright Red for Cancelled
  };


  const fetchData = async () => {
    setLoading(true)
    try {
      const empId = user?.login.employee_UID;

      const res = await getFromAPI(`/Attendance/GetMissedPunchings?empId=${empId}`);


      setMainData(res.data);

    }

    catch (err) {
      console.error("Error fetching missed punch data", err);
    }
    finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchData();
  }, []);



  useEffect(() => {
    const fetchDataLocation = async () => {
      setLoading(true);
      try {

        const empId = user?.employee_UID;

        let apiUrl = '';
        if (selectedLocation === 'Office') {
          apiUrl = `/Location/GetOfficeLocation?empId=${empId}`;
        } else if (selectedLocation === 'Site') {
          apiUrl = `/Location/GetSiteLocation?empId=${empId}`;
        } else {
          setLocations([]);
          setLoading(false);
          return;
        }

        const response = await getFromAPI(apiUrl);

        if (response.status && response.data) {
          const newLocations = selectedLocation === 'Office'
            ? response.data.officeLocationList || []
            : response.data.siteLocationList || [];
          setLocations(newLocations);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchDataLocation();
  }, [selectedLocation]);

  const formatDate = (date) => {
    let d = new Date(date);
    return `${('0' + (d.getMonth() + 1)).slice(-2)}/${('0' + d.getDate()).slice(-2)}/${d.getFullYear()}`;
  };

  const fetchPunchData = async (date) => {
    setLoading(true);
    try {
      const formattedDate = formatDate(date);
      const endpoint = `/Attendance/CheckAlreadyPunch?date=${formattedDate}&employeeId=${user.login.employee_UID}`;
      const result = await getFromAPI(endpoint);

      console.log(result, "resuitsfdcy")

      if (result.status && result.data.length > 0) {
        setPunchData(result.data[0]);
      } else {
        setPunchData(null);
      }
    } catch (error) {
      console.error('Error fetching punch data:', error);
      setPunchData(null);
    }
    setLoading(false);
  };

  const openModal = () => {
    setModalVisible(true);
    setShowForm(false);
    fetchPunchData(selectedDate);
  };

  const onDateChange = (event, selected) => {
    if (selected) {
      setSelectedDate(selected);
      fetchPunchData(selected);
    }
    setShowDatePicker(false);
  };

  const openNewRequestForm = () => setShowForm(true);

  const handleClose = () => {
    setShowForm(false);
    setModalVisible(false);
  }

  const handleCancel = async (item) => {
    try {
      setLoading(true)
      let data = {
        attendanceId: item.attendanceID,
        missedPunchingId: item.uid,
        employeeId: item.employee_UID,
        isRequestAccept: 11,
        approveRemarks: 'Cancelled',

      }
      const apiEndpoint = '/Attendance/UpdateMissedPunching?' + getAPIFormat(data);
      const res1 = await putToAPI(apiEndpoint);

    }
    catch (e) {
      console.log("EROOR", e)
    }
    finally {
      setLoading(false)
      fetchData()
    }
  };

  const handleSave = async () => {
    setLoading(true)
    try {

      {

        if (!chosenLocation) {
          Toast.show({
            type: "error",
            text1: "Please Choose Location",
          });
          return;
        }
      }
      {

        if (!fromTime || !toTime) {
          Toast.show({
            type: 'error',
            text1: "Please select both From Time and To Time",
          });
          return;
        }
      }
      {

        if (!remarks) {
          Toast.show({
            type: 'error',
            text1: "Fill Remarks",
          });
          return;
        }
      }

      const sessionId = user.token.token;



      const selectedLocationObj = locations.find(loc =>
        selectedLocation === 'Office'
          ? loc.location === chosenLocation
          : loc.siteName === chosenLocation
      );

      if (FromTimeDateAPI) {
        const fromTime = new Date(FromTimeDateAPI);

        // Extract the hours and minutes
        const hours = fromTime.getHours();
        const minutes = fromTime.getMinutes();

        // Set the target time to 9:00 AM (09:00)
        const targetHour = 9;
        const targetMinute = 0;

        // Compare the times to check if it's after 9:00 AM
        if (hours < targetHour || (hours === targetHour && minutes < targetMinute)) {
          // If the time is before 9:00 AM
          Toast.show({
            type: "error",
            text1: "Change Selected From Time",
            text2: "Permission can be applied only after 9:00 AM",
          });
          console.log("The time is before 9:00 AM.");
          return;  // Exit the function or prevent further processing
        }
      }

      //to time should bot be more than 630
      if (ToTimeDateAPI) {
        // Parse the ToTimeDateAPI to get the time
        const toTime = new Date(ToTimeDateAPI);

        // Extract the hours and minutes
        const hours = toTime.getHours();
        const minutes = toTime.getMinutes();

        // Convert 6:30 PM (18:30) to hours and minutes for comparison
        const targetHour = 18;
        const targetMinute = 30;

        // Compare the times
        if (hours > targetHour || (hours === targetHour && minutes > targetMinute)) {
          // If the time is greater than 18:30 (6:30 PM)
          Toast.show({
            type: "error",
            text1: "Change Selected To Time",
            text2: "Permission  can be applied only before 6.30 PM ",
          });
          console.log("The time is greater than 6:30 PM.");
          return
        }
      }

      //from cannot be geater than to time
      if (FromTimeDateAPI && ToTimeDateAPI) {
        // Convert the From and To times to Date objects
        const fromTime = new Date(FromTimeDateAPI);
        const toTime = new Date(ToTimeDateAPI);

        // Compare the two times
        if (fromTime > toTime) {
          // If FromTimeDateAPI is greater than ToTimeDateAPI
          Toast.show({
            type: "error",
            text1: "Invalid Time Range",
            text2: "From time cannot be later than To time",
          });
          console.log("From time is greater than To time.");
          return;  // Prevent further logic or action if time is invalid
        }
      }

      const isoDateStr = `${selectedDate.toISOString().split('T')[0]}T00:00:00.000`;
      const isoDateStrd = selectedDate.toISOString().split('T')[0];

      // const fromTime24 = convertTo24Hour(fromTime);
      // const toTime24 = convertTo24Hour(toTime);
      const fullFromTime = mergeDateTimeforDatePicker(date, FromTimeDateAPI);
      const fullToTime = mergeDateTimeforDatePicker(date, ToTimeDateAPI);

      const createdDate = new Date(); // current time in IST
      const createdDateIST = new Date(createdDate.getTime() + (5.5 * 60 * 60 * 1000)).toISOString().replace('Z', '');




      const payload = {
        uid: 0,
        employee_UID: user.login.employee_UID,
        attendanceID: 0,
        roll_UID: user.login.rollUID,
        punching_Type: 1,
        date: isoDateStr,
        fromTime: fullFromTime,
        toTime: fullToTime,
        location_UID: user.login.uid,
        location_Type: selectedLocation,
        location: chosenLocation,
        approve_remarks: "",
        status: 1,
        remark: remarks,
        createdBy: user.login.employee_UID,
        createdDate: createdDateIST,
        modifiedBy: user.login.employee_UID,
        modifiedDate: createdDateIST
      };


      console.log(payload, "payload")

      const result = await postToAPI(`/Attendance/RequestMissedPunching`, payload, {
        headers: { SessionId: sessionId }
      });

      console.log(result, "result")

      if (result.status) {
        Toast.show({
          type: 'success',
          text1: "Missed punch request submitted successfully",
        });
        alert(result.message)
        setModalVisible(false);
        setShowForm(false);
        fetchData();
      } else {
        console.log("eroor")
        alert(result.message)
        Toast.show({
          type: 'error',
          text1: "Submission failed. Try again.",
        });
      }
    } catch (error) {
      console.error('Error submitting request:', error);
      Toast.show({
        type: 'error',
        text1: "Something went wrong.",
      });
    }
    finally {
      setLoading(false);
    }
  };


  return (
    <View style={styles.container}>
      <Loader visible={loading} />

      <FlatList
        data={MainData}
        keyExtractor={(item, index) => item?.uid?.toString() || index.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.row}>
              <Text style={styles.label}>Date:</Text>
              <Text style={styles.value}>{formatTOddmmyy(item.date)}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>From Time:</Text>
              <Text style={styles.value}>{formatDateTimeFromApiToUITimeOnly(item.fromTime)}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>To Time:</Text>
              <Text style={styles.value}>{formatDateTimeFromApiToUITimeOnly(item.toTime)}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>Reason:</Text>
              <Text style={styles.value}>{item.remark}</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.label}>Status:</Text>
              <Text style={[styles.status, { color: StatusColor[item.status] }]}>
                {StatusMessage[item.status]}
              </Text>
            </View>

            {item.status === 1 && <TouchableOpacity style={styles.cancelButton} onPress={() => handleCancel(item)}>
              <Text style={styles.buttonText}>Cancel</Text>
            </TouchableOpacity>}
          </View>
        )}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <Text style={{ textAlign: "center", marginTop: 20, color: "red" }}>No data available</Text>
        }
      />


      <TouchableOpacity style={styles.floatingButton} onPress={openModal}>
        <MaterialIcons name="add" size={30} color="white" />
      </TouchableOpacity>
      <Modal visible={modalVisible} animationType="slide">
        <SafeAreaView style={styles.modalContainer}>

          <View style={styles.modalContent}>
            {showForm ? (
              <>
                <Text style={styles.modalTitle}>Missed Punch In & Out</Text>
                <Text style={styles.inputLabel}>Date</Text>
                <TouchableOpacity onPress={() => setShowDatePicker(true)} style={styles.datePickerButton}>
                  <Text style={styles.dateText}>{formatDate(selectedDate)}</Text>
                </TouchableOpacity>

                <View style={styles.locationContainer}>
                  {["Office", "Site"].map((loc) => (
                    <TouchableOpacity
                      key={loc}
                      style={[styles.locationButton, selectedLocation === loc && styles.selectedLocationButton]}
                      onPress={() => setSelectedLocation(loc)}
                    >
                      <Text style={selectedLocation === loc ? styles.selectedText : styles.unselectedText}>
                        {loc}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <Text style={styles.label}>Choose Location</Text>
                {loading ? (
                  <ActivityIndicator size="small" color="#007bff" />
                ) : (
                  <Dropdown
                    data={locations}
                    label={selectedLocation === "Office" ? "location" : "siteName"}
                    value={selectedLocation === "Office" ? "location" : "siteName"}
                    Selectdp={chosenLocation}
                    setSelectdp={setChosenLocation}
                    heading="Select a location..."
                  />
                )}

                <Text style={styles.inputLabel}>Missed Punch Type</Text>
                <View style={styles.picker}>
                  <Dropdown
                    data={missedPunchOptions.map((item) => ({ label: item, value: item }))}
                    label="label"
                    value="value"
                    Selectdp={missedPunchType}
                    setSelectdp={setMissedPunchType}
                    heading="Select Punch Type..."
                    searchable={false}
                  />
                </View>

                <View style={styles.timeContainer}>
                  <TouchableOpacity style={styles.timeBox} onPress={() => setShowFromTimePicker(true)}>
                    <MaterialIcons name="access-time" size={24} color="#007bff" />
                    <Text style={styles.inputText}>From : </Text>
                    <Text style={styles.inputTime}>{fromTime ? formatDateTimeFromApiToUITimeOnly(fromTime) : ""}</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={styles.timeBox} onPress={() => setShowToTimePicker(true)}>
                    <MaterialIcons name="access-time" size={24} color="#007bff" />
                    <Text style={styles.inputText}>To : </Text>
                    <Text style={styles.inputTime}>{toTime ? formatDateTimeFromApiToUITimeOnly(toTime) : ""}</Text>
                  </TouchableOpacity>
                </View>

                <TextInput
                  style={styles.input}
                  placeholder="Remarks"
                  value={remarks}
                  onChangeText={setRemarks}
                />

                <View style={styles.buttonContainer}>
                  <TouchableOpacity style={styles.cancelButton2} onPress={handleClose}>
                    <Text style={styles.buttonText4}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.saveButton2} onPress={handleSave}>
                    <Text style={styles.buttonText2}>Save</Text>
                  </TouchableOpacity>
                </View>
              </>
            ) : (
              <>
                <Text style={styles.modalTitle}>Missed Punch Records</Text>
                <TouchableOpacity style={styles.datePickerButton} onPress={() => setShowDatePicker(true)}>
                  <Text style={styles.dateText}>Selected Date: {formatDate(selectedDate)}</Text>
                </TouchableOpacity>

                {loading ? (
                  <ActivityIndicator size="large" color="#007bff" />
                ) : punchData ? (
                  <View style={styles.punchContainer}>
                    <Text style={styles.modalTitle}>{punchData.location}</Text>
                    <Text style={styles.punchText}>
                      Punch In: {new Date(punchData.punchInTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true })}
                    </Text>
                    <Text style={styles.punchText}>
                      Punch Out: {new Date(punchData.punchOutTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true })}
                    </Text>
                  </View>
                ) : (
                  <Text style={styles.noDataText}>No data available.</Text>
                )}

                <View style={styles.buttonContainer}>
                  <TouchableOpacity style={styles.requestButton} onPress={openNewRequestForm}>
                    <Text style={styles.buttonText2}>New Request</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.cancelButton2} onPress={handleClose}>
                    <Text style={styles.buttonText3}>Back</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </View>
        </SafeAreaView>
      </Modal>

      {/* DateTimePickers outside Modal */}
      {showDatePicker && (
        <DateTimePicker value={selectedDate} mode="date" display="default" onChange={onDateChange} />
      )}

      {Platform.OS === 'android' && showFromTimePicker && (
        <DateTimePicker
          value={fromTime || new Date()}
          mode="time"
          display="default"
          onChange={(event, selectedTime) => {
            setShowFromTimePicker(false);
            if (selectedTime) {
              setFromTime(selectedTime);
              setFromTimeDateAPI(DateTimePickerToApiFormat(selectedTime));
            }
          }}
        />
      )}

      {Platform.OS === 'android' && showToTimePicker && (
        <DateTimePicker
          value={toTime || new Date()}
          mode="time"
          display="default"
          onChange={(event, selectedTime) => {
            setShowToTimePicker(false);
            if (selectedTime) {
              setToTime(selectedTime);
              setToTimeDateAPI(DateTimePickerToApiFormat(selectedTime));
            }
          }}
        />
      )}

      <Toast />
    </View>
  );
};

export default MissedPunchScreen;

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f5f5f5' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 20 },
  card: {
    backgroundColor: "#FFF",
    padding: 20,
    borderRadius: 10,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },
  inputTime: {
  fontSize: 16,
  color: "black",
  flexShrink: 1, // ✅ Prevent text overflow
},
  timeBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    flex: 1,
    justifyContent: "flex-start",
    marginRight: 5,
    borderWidth: 1, // ✅ Added border
    borderColor: "black", // ✅ Dull Red Border
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
    padding: 5
  },
  label: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
    color: "black",
  },
  value: {
    fontSize: 18, // Increased font size
    color: "#333",
  },
  status: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
  },
  timeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  cancelButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
  },
  buttonText: {
    color: "#D32F2F",  // ✅ Same color as border
    fontSize: 18,
    fontWeight: "bold",
  },
  backText: {
    color: "#007bff",
    fontWeight: "bold",
  },
  backButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#007bff",  // ✅ Outline color
  },
  floatingButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    width: 70, // Increased size
    height: 70,
    borderRadius: 35,
    backgroundColor: "#D32F2F",
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  modalContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' },
  modalContent: { width: '90%', backgroundColor: '#fff', padding: 20, borderRadius: 10 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },

  datePickerButton: { padding: 10, backgroundColor: '#ffffff', borderRadius: 10, alignItems: 'center', marginBottom: 12, borderWidth: 2, borderColor: 'grey' },
  dateText: { color: '#000000', fontSize: 16, fontWeight: 'bold' },

  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 5, padding: 10, marginBottom: 10 },
  picker: { borderWidth: 1, borderColor: '#ccc', borderRadius: 5, marginBottom: 10 },
  inputLabel: { fontWeight: 'bold', marginBottom: 5 },
  label: { fontWeight: 'bold', marginBottom: 5 },
  locationContainer: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 10 },
  locationButton: { padding: 10, borderRadius: 5, borderWidth: 1, borderColor: '#007bff' },
  selectedLocationButton: { backgroundColor: '#007bff' },
  selectedText: { color: '#fff' },
  unselectedText: { color: '#007bff' },
  punchContainer: { marginBottom: 15 },
  punchText: { fontSize: 16, marginVertical: 3 },
  noDataText: { color: '#777', marginBottom: 15 },
  buttonContainer: { flexDirection: 'row', justifyContent: 'space-between' },
  cancelButton2: { padding: 10, backgroundColor: '#ffffff', borderRadius: 8, width: '48%', alignItems: 'center', borderWidth: 2, borderColor: 'red' },


  saveButton2: { padding: 10, backgroundColor: '#ffffff', borderRadius: 8, width: '48%', alignItems: 'center', borderWidth: 2, borderColor: '#007bff' },


  requestButton: { padding: 10, backgroundColor: '#ffffff', borderRadius: 8, width: '48%', alignItems: 'center', borderWidth: 2, borderColor: '#007bff' },


  buttonText2: { color: '#007bff', fontSize: 16, fontWeight: 'bold' },

  buttonText4: { color: 'red', fontSize: 16, fontWeight: 'bold' },


  buttonText3: { color: 'red', fontSize: 16, fontWeight: 'bold' },

});