import React, { useState, useEffect, useLayoutEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ActivityIndicator, FlatList, ScrollView } from 'react-native';
import { RadioButton } from 'react-native-paper';
import RNPickerSelect from 'react-native-picker-select';
import { getFromAPI, putToAPI, postToAPI } from '../../apicall/apicall';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Dropdown from '../../component/dropdown2/DropDown';
import { getCurrentLocation, getCurrentTimeAndDate } from '../../component/Utils/locationHelper';
import { Alert } from 'react-native';
import BackgroundTimer from 'react-native-background-timer';
import { useNavigation } from '@react-navigation/native';
import { formatDateTimeFromApiToUITimeOnly, FromandToformat, getDay, getMonth } from "../../shared/sharedFunctions";
import { useAuth } from "../../auth/AuthContext";
import { Card } from "react-native-paper";
import Loader from '../../component/loader/Loader'
import Toast from "react-native-toast-message";
import { useFocusEffect, useRoute } from "@react-navigation/native";







const AttendanceScreen = () => {
  const [selectedLocation, setSelectedLocation] = useState('Office');
  const [chosenLocation, setChosenLocation] = useState('');
  const [chosenLocation2, setChosenLocation2] = useState('');
  const [attendanceStatus, setAttendanceStatus] = useState('Reached');
  const [remarks, setRemarks] = useState('');
  const [locations, setLocations] = useState([]);
  const [latitude, setLatitude] = useState(null);
  const [longitude, setLongitude] = useState(null);
  const [currentDateTime, setCurrentDateTime] = useState(getCurrentTimeAndDate());
  const [loading, setLoading] = useState(false);
  const [isPunchedIn, setIsPunchedIn] = useState(false);
  const [attendanceData, setAttendanceData] = useState([]);
  const [initialStatus, setInitialStatus] = useState('');
  const [statusUpdated, setStatusUpdated] = useState(false);
  const [hasManuallyPunchedOut, setHasManuallyPunchedOut] = useState(false);
  const [attendanceUid, setAttendanceUid] = useState(0);
  const [checkattendance, setcheckattendance] = useState(false);
  const route = useRoute();






  const resetFormStates = () => {
    setSelectedLocation('Office');
    setAttendanceStatus('Reached');
    setRemarks('');
    setChosenLocation('');
    setChosenLocation2('');
    // setLatitude(null);
    // setLongitude(null);
    // setCurrentDateTime(getCurrentTimeAndDate());
    // setLoading(false);
    // setIsPunchedIn(false);
    // setInitialStatus('');
    // setStatusUpdated(false);
    // setHasManuallyPunchedOut(false);
  };

  const { user } = useAuth();

  const formatPunchOutDate = (date) => {
    const pad = (n) => (n < 10 ? '0' + n : n);

    const year = date.getFullYear();
    const month = pad(date.getMonth() + 1);
    const day = pad(date.getDate());
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    const seconds = pad(date.getSeconds());
    const milliseconds = date.getMilliseconds();

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
  };


  const formatDate = (date) => {

    let d = new Date(date);
    return `${('0' + (d.getMonth() + 1)).slice(-2)}/${('0' + d.getDate()).slice(-2)}/${d.getFullYear()}`;
  };


  // useFocusEffect(
  //   React.useCallback(() => {
  //     if (route.params?.refresh) {
  //       fetchData();
  //     }
  //   }, [route.params?.refresh])
  // );


  const fetchData = async () => {
    // console.log("fetchData called")
    const now = new Date();

    const sixThirty = new Date();
    sixThirty.setHours(18, 30, 0, 0);
    if (now > sixThirty) {
      return;
    }

    if (hasManuallyPunchedOut || now > sixThirty) {
      return;
    }

    const formattedDate = formatDate(now);
    const endpoint = `/Attendance/CheckAlreadyPunch?date=${formattedDate}&employeeId=${user.login.employee_UID}`;

    try {
      const result = await getFromAPI(endpoint);

      // console.log(result, "result of data fetched")

      if (result?.data && Array.isArray(result.data)) {
        const autoPunchOutData = result.data.filter((item) => {
          const isToday = formatDate(item.date) === formattedDate;
          const isAutoPunch = item.remark === "AutoPunch out";

          if (!isToday || !isAutoPunch || !item.punchOutTime) return false;

          const punchOutDate = new Date(item.punchOutTime);
          const hours = punchOutDate.getHours();
          const minutes = punchOutDate.getMinutes();
          const seconds = punchOutDate.getSeconds();

          return hours === 18 && minutes === 30 && seconds === 0;
        });
        if (autoPunchOutData.length == 0){
          setcheckattendance(true)
        }
        // console.log(autoPunchOutData,"autoPunchOutData123")

        if (autoPunchOutData.length > 0) {
          const sortedData = autoPunchOutData.sort((a, b) => new Date(b.punchInTime) - new Date(a.punchInTime));
          const selected = sortedData[0];

          // console.log(selected, "selected data")
          setAttendanceUid(selected.uid);



          if (selected.address === "Office Site") {
            setSelectedLocation("Office");
            setChosenLocation(selected.location);
          } else if (selected.siteId !== 0) {
            setSelectedLocation("Site");
            setChosenLocation(selected.location);
          }
          else if (selected.locationId === 0) {
            setSelectedLocation("Others");
            setChosenLocation2(selected.location);
          }

          setAttendanceStatus(selected.attendance_Type === 1 ? "Reached" : "On the way");
          setIsPunchedIn(true);
          setAttendanceUid(selected.uid)
        }
      }
    } catch (error) {
      console.error("Error fetching attendance data:", error);
    }
  };
 

  useLayoutEffect(() => {
    

    fetchData();
  }, [hasManuallyPunchedOut]);





  const navigation = useNavigation();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {

        const DataToAPI = {
          empId: user.login.employee_UID,
        };

        let apiUrl = '';
        if (selectedLocation === 'Office') {
          apiUrl = `/Location/GetOfficeLocation?empId=${DataToAPI.empId}`;
        } else if (selectedLocation === 'Site') {
          apiUrl = `/Location/GetSiteLocation?empId=${DataToAPI.empId}`;
        } else {
          setLocations([]);
          setLoading(false);
          return;
        }

        const response = await getFromAPI(apiUrl);


        if (response.status && response.data) {
          let newLocations = [];

          if (selectedLocation === 'Office') {
            newLocations = response.data.officeLocationList || [];
          } else if (selectedLocation === 'Site') {
            newLocations = response.data.siteLocationList || [];
          }

          // console.log(response.data.siteLocationList, "response.data.siteLocationList 123")

          if (JSON.stringify(newLocations) !== JSON.stringify(locations)) {
            setLocations(newLocations);
          }

          setAttendanceData(response.data.recentAttendance);

        }
      } catch (e) {
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [selectedLocation]);

  const handlePunchIn = async () => {
    try {
      setLoading(true);

      const userData = await AsyncStorage.getItem('IECUser');

      const user = userData ? JSON.parse(userData) : {};

      const location = await getCurrentLocation();
      const punchInTime = getCurrentTimeAndDate();

      const getTodayAt1830 = () => {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}T18:30:00`;
      };

      const punchIn = new Date(punchInTime);
      const punchOut = new Date(getTodayAt1830());
      const diffMs = punchOut - punchIn;
      const calculatedHours = Math.floor(diffMs / (1000 * 60 * 60));
      const calculatedMinutes = Math.floor((diffMs / (1000 * 60)) % 60);



      let locationId = 0;
      let locationName = '';
      let siteId = 0;
      let siteName = '';

      if (selectedLocation === "Office") {
        const selected = locations.find((loc) => loc.location === chosenLocation);
        locationId = selected?.uid || 0;
        locationName = selected?.location || '';
      } else if (selectedLocation === "Site") {
        const selected = locations.find((loc) => loc.siteName === chosenLocation);
        siteId = selected?.uId;
        siteName = selected?.siteName || '';
      } else {
        locationName = chosenLocation2;
      }

      // console.log(siteId, "siteId")


      const finalChosenLocation = selectedLocation === 'Others' ? chosenLocation2 : chosenLocation;

      const finalChosenLocation2 =
        selectedLocation === 'Office'
          ? 'Office Site'
          : selectedLocation === 'Others'
            ? chosenLocation2
            : chosenLocation;

      if (!finalChosenLocation) {
        Toast.show({
                  type: 'error',
                  text1: 'Please select a location or enter it manually.',
                });
        setLoading(false);
        return;
      }

      if (!finalChosenLocation2) {
        Toast.show({
          type: 'error',
          text1: '"Please select a location or enter it manually.',
        });
        setLoading(false);
        return;
      }

      
      let status = 0;
      let attendanceType = 0;

      if (attendanceStatus === 'Reached') {
        status = 1;
        attendanceType = 1;
      } else if (attendanceStatus === 'On the way') {
        status = 2;
        attendanceType = 2;
      }

      console.log(status, attendanceType, "status")

      const payload = {
        uid: 0,
        employee_UID: user?.login?.employee_UID,
        employeeName: user?.userName,
        latitude: location?.latitude,
        longitude: location?.longitude,
        punchOutLatitude: 0,
        punchOutLongitude: 0,
        address: finalChosenLocation2,
        ipAddress: "",
        locationId: locationId,
        location: finalChosenLocation,
        siteId: siteId,
        siteName: siteName,
        attendance_Type: attendanceType,
        status: status,
        date: punchIn,
        punchInTime: punchIn,
        punchOutTime: getTodayAt1830(),
        totalHours: calculatedHours,
        totalMinutes: calculatedMinutes,
        login_UID: user?.login?.app_RollUID,
        client_UID: 0,
        roll_UID: user?.login?.rollUID,
        remark: '',
        modifiedBy: user?.login?.employee_UID,
        modifiedDate: punchIn,
        missedPunchInTime: punchIn,
        missedPunchOutTime: getTodayAt1830()
      };

      // console.log(payload, "payload current ")




      const response = await postToAPI('/Attendance/Check_In', payload);

      // console.log(response, "response from api")

      if (response) {
        Toast.show({
          type: 'success',
          text1: response.message,
        });
        setIsPunchedIn(true);
        setInitialStatus(attendanceStatus);
      } else {
        Toast.show({
          type: 'error',
          text1: 'Failed to record Punch In.',
        });
      }
    } catch (error) {
      Toast.show({
        type: 'error',
        text1: error.message || "Something went wrong!",
      });
    } finally {
      setLoading(false);
    }
  };




  const handleUpdateStatus = async () => {
    try {
      setLoading(true);

      const userData = await AsyncStorage.getItem('IECUser');
      const user = userData ? JSON.parse(userData) : {};
  
      let status = 0;
      let attendanceType = 0;

      if (attendanceStatus === 'Reached') {
        status = 1;
        attendanceType = 2;
      } else if (attendanceStatus === 'On the way') {
        status = 2;
        attendanceType = 1;
      }


          const attendanceid = attendanceUid;


          


          const response = await putToAPI(`/Attendance/UpdateAttendanceStatus?attendanceUId=${attendanceid}&AttendanceStatus=${status}`)
          Toast.show({
            type: 'success',
            text1:response.message,
          });

          // console.log(response, "response from api")
         

        
      

    } catch (error) {
      Toast.show({
        type: 'error',
        text1:  error.message || "Something went wrong!",
      });
    } finally {
      resetFormStates()
      setLoading(false);
    }
  };



  // useEffect(() => {
  //   if (isPunchedIn && initialStatus === 'On the way' && attendanceStatus === 'Reached') {
  //     setStatusUpdated(true);
  //     setInitialStatus(attendanceStatus);
  //   } else {
  //     setStatusUpdated(false);
  //   }
  // }, [ initialStatus, attendanceStatus, isPunchedIn]);


  useEffect(() => {
    fetchLocation();
    const interval = setInterval(() => {
      setCurrentDateTime(getCurrentTimeAndDate());
    }, 500);

    return () => clearInterval(interval);
  }, []);


  const fetchLocation = async () => {
    setLoading(true);
    try {
      const location = await getCurrentLocation();
      setLatitude(location.latitude);
      setLongitude(location.longitude);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handlePunchOut = async () => {
    const date = new Date();
    const formattedDate = formatDate(date);
    const endpoint = `/Attendance/CheckAlreadyPunch?date=${formattedDate}&employeeId=${user.login.employee_UID}`;

    try {
      const result = await getFromAPI(endpoint);
      // console.log(result, "result of data fetched2222")


      if (result?.data && Array.isArray(result.data)) {
        const autoPunchOutData = result.data.filter((item) => {
          const isToday = formatDate(item.date) === formattedDate;
          const isAutoPunch = item.remark === "AutoPunch out";

          if (!isToday || !isAutoPunch || !item.punchOutTime) return false;

          const punchOutDate = new Date(item.punchOutTime);
          const hours = punchOutDate.getHours();
          const minutes = punchOutDate.getMinutes();
          const seconds = punchOutDate.getSeconds();

          return hours === 18 && minutes === 30 && seconds === 0;
        });


        if (autoPunchOutData.length > 0) {
          const sortedData = autoPunchOutData.sort((a, b) => new Date(b.punchInTime) - new Date(a.punchInTime));
          const selected = sortedData[0];
          setLoading(true);
          // console.log(selected, "selected  data fetched")



          const location = await getCurrentLocation();
          const punchOutDateFormatted = formatPunchOutDate(new Date());


          const queryParams = new URLSearchParams({
            attendanceId: selected.uid.toString(),
            punchOutDate: punchOutDateFormatted,
            punchOutLatitude: location.latitude.toString(),
            punchOutLongitude: location.longitude.toString(),
            remarks: '',
          }).toString();


          const response = await putToAPI(`/Attendance/Check_Out?${queryParams}`,
            null)
          Toast.show({
            type: 'success',
            text1: response.message,
          });
          setHasManuallyPunchedOut(true);
          setIsPunchedIn(false);


        }
      }

    } catch (error) {
      Toast.show({
        type: 'error',
        text1: error.message || "Something went wrong!",
      });
    } finally {
      resetFormStates()
      fetchData();
      setLoading(false);
      // navigation.navigate("Attendance", { refresh: true });

    }
  };





  useEffect(() => {
    const checkAutoPunchOut = setInterval(async () => {
      const currentTime = new Date();
      if (currentTime.getHours() === 18 && currentTime.getMinutes() === 30) {
        await handlePunchOut();
      }
    }, 60000); // Check every minute

    return () => clearInterval(checkAutoPunchOut);
  }, []);


  const AttendanceCard = ({ item }) => (
    <Card style={styles.card}>
      <View style={styles.cardRow}>
        {/* Date Container */}
        <View style={styles.dateContainer}>
          <Text style={styles.dateText}>{getMonth(item.date)}</Text>
          <Text style={styles.dateText}>{getDay(item.date)}</Text>
        </View>

        {/* Details Container */}
        <View style={styles.detailsContainer}>
          <View style={styles.cardContent}>
            <View>
              <Text style={styles.officeText}>
                {item.location} ({item.totalHours} Hrs)
              </Text>
              <Text style={styles.timeText}>
                {formatDateTimeFromApiToUITimeOnly(item.punchInTime)} - {formatDateTimeFromApiToUITimeOnly(item.punchOutTime)}
              </Text>
            </View>

          </View>

        </View>
      </View>
    </Card>
  );



  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
      <View style={styles.container}>
        <Loader visible={loading} />
        {/* Location Section */}
        <View style={styles.locationContainer}>
          {[{ name: 'Office', icon: require('../../assets/workplace2.png') }, { name: 'Site', icon: require('../../assets/location.png') }, { name: 'Others', icon: require('../../assets/industry2.png') }].map((location) => (
            <TouchableOpacity key={location.name} style={[styles.locationButton, selectedLocation === location.name && styles.selectedLocationButton]} onPress={() => {
              setSelectedLocation(location.name);
              if (location.name === "Office" || location.name === "Site") {
                setChosenLocation(location.name);
              }
            }}>
              <Image source={location.icon} style={styles.icon} />
              <Text style={selectedLocation === location.name ? styles.selectedText : styles.unselectedText}>{location.name}</Text>
            </TouchableOpacity>
          ))}
        </View>


        <View>
          <Text style={styles.label}>Choose Location</Text>
          {selectedLocation === 'Others' ? (
            <TextInput
              style={styles.input}
              placeholder="Enter place..."
              value={chosenLocation2}
              onChangeText={setChosenLocation2}
            />
          ) : (
            <Dropdown
              data={locations}
              label={selectedLocation === 'Office' ? 'location' : 'siteName'}
              value={selectedLocation === 'Office' ? 'location' : 'siteName'}
              Selectdp={chosenLocation}
              setSelectdp={setChosenLocation}
              heading="Select a location..."
            />
          )}



          <View style={styles.statusContainer}>
            <View style={styles.statusBox}>
              <RadioButton.Group
                onValueChange={(value) => {
                  if(checkattendance){
                    setAttendanceStatus(value)
                  }
                  else{
                     setAttendanceStatus(value)
                    setStatusUpdated(false)
                    setStatusUpdated(true)
                  }
                }}
                value={attendanceStatus}
              >
                <Text style={styles.label}>Attendance Status</Text>
                <View style={styles.radioOption}>
                  <RadioButton value="Reached" />
                  <Text style={styles.radioText}>Reached</Text>
                </View>
                <View style={styles.radioOption}> 
                  <RadioButton value="On the way" />
                  <Text style={styles.radioText}>On the way</Text>
                </View>
                {statusUpdated && (
                  <TouchableOpacity
                    style={styles.updateStatusButton}
                    onPress={handleUpdateStatus}
                  >
                    <Text style={styles.buttonText}>Update Status</Text>
                  </TouchableOpacity>
                )}
              </RadioButton.Group>
            </View>
          </View>


          {/* Remarks Input */}
          <Text style={styles.label}>Remarks</Text>
          <TextInput style={styles.input} placeholder="Enter remarks..." value={remarks} onChangeText={setRemarks} />

          {/* Buttons */}
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={[styles.punchInButton, isPunchedIn && styles.disabledButton]}
              onPress={handlePunchIn}
              disabled={isPunchedIn} // ✅ Disable when punched in
            >
              <Text style={styles.buttonText}>Punch In</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.punchOutButton}
              onPress={handlePunchOut}
            >
              <Text style={styles.buttonText}>Punch Out</Text>
            </TouchableOpacity>
          </View>


          {/* Missed Punch Button */}
          <TouchableOpacity
            style={styles.missedPunchButton}
            onPress={() => navigation.navigate("MissedPunchScreen")}
          >
            <Text style={styles.missedButtonText}>Missed Punch</Text>
          </TouchableOpacity>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10, paddingHorizontal: 5 }}>
          <Text style={styles.label}>Recent Attendance (last 30 days)</Text>
          <TouchableOpacity onPress={() => navigation.navigate("AttendanceList")}>
            <Text style={{ color: '#007bff' }}>View All</Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={attendanceData.slice(0, 30)}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => <AttendanceCard item={item} />}
          showsVerticalScrollIndicator={false}
        />
      </View>
    </ScrollView>


  );
};

export default AttendanceScreen;

const styles = StyleSheet.create({

  disabledButton: {
    backgroundColor: 'gray',
  },
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  locationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  locationButton: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 100,
    height: 100,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginHorizontal: 5,
    elevation: 3,
  },
  selectedLocationButton: {
    backgroundColor: '#007bff',
  },
  icon: {
    width: 40,
    height: 40,
    marginBottom: 5,
  },
  selectedText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  unselectedText: {
    color: '#000',
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  inputContainer: {
    position: 'relative',
  },
  input: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#000',
  },
  radioGroup: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  radioOption: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  radioText: {
    marginLeft: 5,
  },
  statusContainer: {
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  punchInButton: {
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 10,
    width: '48%',
    alignItems: 'center',
  },
  punchOutButton: {
    backgroundColor: 'lightgray',
    padding: 10,
    borderRadius: 10,
    width: '48%',
    alignItems: 'center',
  },

  buttonText: {
    color: 'black',
    fontWeight: 'bold',
  },
  missedPunchButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 10,
    marginTop: 10,
    alignItems: 'center',
  },
  missedButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  dropdownItem: {
    backgroundColor: '#fff',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  card: {
    marginVertical: 8,
    padding: 15,
    borderRadius: 10,
    backgroundColor: "#fff",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  absentCard: {
    backgroundColor: "#f8d7da",
  },
  cardRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  dateContainer: {
    backgroundColor: "#007bff",
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  dateText: {
    color: "white",
    fontWeight: "bold",
  },
  detailsContainer: {
    flex: 1, // Takes up the remaining space
    marginLeft: 10,
  },
  cardContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  officeText: {
    fontSize: 16,
  },
  timeText: {
    fontSize: 14,
    color: "gray",
  },
  dailyText: {
    color: "red",
    fontWeight: "bold",
  },
  statusBox: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    marginVertical: 10,
    elevation: 2,
  },
  updateStatusButton: {
    backgroundColor: 'green',
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },

});

const pickerSelectStyles = {
  inputIOS: {
    fontSize: 16,
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 8,
    backgroundColor: 'white',
    color: 'black',
  },
  inputAndroid: {
    fontSize: 16,
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 8,
    backgroundColor: 'white',
    color: 'black',
  },
};
