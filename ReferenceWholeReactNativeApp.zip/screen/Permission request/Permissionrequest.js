import React, { useState, useEffect } from "react";
import { View, Dimensions, Text, FlatList, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import { MaterialIcons } from "@expo/vector-icons";
import { postToAPI, getFromAPI, putToAPI } from '../../apicall/apicall'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAPIFormat } from '../../apicall/apifFromats'
import { useAuth } from '../../auth/AuthContext'
import { formatTOddmmyy, formatDateTimeFromApiToUITimeOnly, DateTimePickerToApiFormat, getCurrDateTime, mergeDateTimeforDatePicker } from '../../shared/sharedFunctions'
import Loader from '../../component/loader/Loader'
import Toast from "react-native-toast-message";

const PermissionRequestForm = () => {
  const { width, height } = Dimensions.get('window');
  const [Load, setLoad] = useState(false)
  const [date, setDate] = useState(new Date()); // for leave date
  const [FromTimeDateAPI, setFromTimeDateAPI] = useState(DateTimePickerToApiFormat(new Date()));
  const [ToTimeDateAPI, setToTimeDateAPI] = useState(DateTimePickerToApiFormat(new Date()));
  const [fromTime, setFromTime] = useState(new Date());
  const [toTime, setToTime] = useState(new Date());
  const [reason, setReason] = useState("");
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showFromTimePicker, setShowFromTimePicker] = useState(false);
  const [showToTimePicker, setShowToTimePicker] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const { user } = useAuth();
  const [MainData, setMainData] = useState([])
  const [Error, setError] = useState(false);
  const [Data, setData] = useState(
    {
      "uid": 0,
      "employee_UID": user.login.employee_UID,
      "roll_UID": user.login.app_RollUID,
      "fromDate": "",
      "toDate": "",
      "remark": "",
      "status": 1,
      "createdDate": "",
      "modifiedBy": user.login.employee_UID,
      "modifiedDate": "",
      "leaveFlag": 0,
      "timeFlag": 0,
      "requestType": 2
    }
  )

  const StatusColor = {
    1: '#FFD700',   // Yellow for Pending
    2: '#28a745',   // Green for Approved
    4: '#FF0000',     // Bright Red for Cancelled
  };

  const handleCancel = async (item) => {
    try {
      setLoad(true)
      const DataToAPI = { ...item };
      DataToAPI.status = 4;
      DataToAPI.modifiedBy = user.login.employee_UID
      console.log("Data To API", DataToAPI)
      const res1 = await putToAPI('/UpdatePermission', DataToAPI)
      console.log("Response After Deletion", res1)
    }
    catch (e) {
      console.log("EROOR", e)
    }
    finally {
      setLoad(false)
      fetchData()
    }
  };

  const fetchData = async () => {
    try {
      setLoad(true)
      // console.log("USERDATA -- 1", user)
      const DataToAPI1 = {
        employeeId: user.login.employee_UID,
        rollId: user.login.app_RollUID
      };
      const [res1] = await Promise.all([
        getFromAPI('/Get-all-Permission/employeeId?' + getAPIFormat(DataToAPI1)), //  5
      ]);
      setMainData(res1.data)
      // console.log("🔹 Data to api", DataToAPI1)
      // console.log("✅ Response 1 :", res1);
    } catch (e) {
      console.error("❌ Error from Permission Request:", e);
    } finally {
      setLoad(false)
    }
  };

  const updateField = (field, val) => {
    let updatedData = { ...Data };
    updatedData[field] = val; // ✅ Correct syntax
    setData(updatedData)
  }

  const updateFieldsMultiple = (fields) => { //to pass multiple fileds at same time and set value
    const updatedData = { ...Data, ...fields };
    setData(updatedData);
  };

  useEffect(() => {
    fetchData()
  }, [])

  const onSubmit = async () => {
    try {
      let alteredData = { ...Data }
      //FORM validations starts ---------
      for (let [key, val] of Object.entries(alteredData)) {
        // if (key != "uid" && key != "status" && key != "modifiedBy" && key != "leaveFlag" && key != "timeFlag" && key != "requestType" && val == "" && val == 0) {
        if (key == 'remark' && (val == "" || val == 0)) {
          setError(true);
          console.log("Eoor", key)
          return;
        }
      }

      //from time should bot be more than 9
      if (FromTimeDateAPI) {
        const fromTime = new Date(FromTimeDateAPI);

        // Extract the hours and minutes
        const hours = fromTime.getHours();
        const minutes = fromTime.getMinutes();

        // Set the target time to 9:00 AM (09:00)
        const targetHour = 9;
        const targetMinute = 0;

        // Compare the times to check if it's after 9:00 AM
        if (hours < targetHour || (hours === targetHour && minutes < targetMinute)) {
          // If the time is before 9:00 AM
          Toast.show({
            type: "error",
            text1: "Change Selected From Time",
            text2: "Permission can be applied only after 9:00 AM",
          });
          console.log("The time is before 9:00 AM.");
          return;  // Exit the function or prevent further processing
        }
      }

      //to time should bot be more than 630
      if (ToTimeDateAPI) {
        // Parse the ToTimeDateAPI to get the time
        const toTime = new Date(ToTimeDateAPI);

        // Extract the hours and minutes
        const hours = toTime.getHours();
        const minutes = toTime.getMinutes();

        // Convert 6:30 PM (18:30) to hours and minutes for comparison
        const targetHour = 18;
        const targetMinute = 30;

        // Compare the times
        if (hours > targetHour || (hours === targetHour && minutes > targetMinute)) {
          // If the time is greater than 18:30 (6:30 PM)
          Toast.show({
            type: "error",
            text1: "Change Selected To Time",
            text2: "Permission  can be applied only before 6.30 PM ",
          });
          console.log("The time is greater than 6:30 PM.");
          return
        }
      }

      //from cannot be geater than to time
      if (FromTimeDateAPI && ToTimeDateAPI) {
        // Convert the From and To times to Date objects
        const fromTime = new Date(FromTimeDateAPI);
        const toTime = new Date(ToTimeDateAPI);

        // Compare the two times
        if (fromTime > toTime) {
          // If FromTimeDateAPI is greater than ToTimeDateAPI
          Toast.show({
            type: "error",
            text1: "Invalid Time Range",
            text2: "From time cannot be later than To time",
          });
          console.log("From time is greater than To time.");
          return;  // Prevent further logic or action if time is invalid
        }
      }

      //donot allow 3 hrs above
      if (FromTimeDateAPI && ToTimeDateAPI) {
        // Convert the From and To times to Date objects
        const fromTime = new Date(FromTimeDateAPI);
        const toTime = new Date(ToTimeDateAPI);

        // Calculate the difference in milliseconds
        const timeDifference = Math.abs(toTime - fromTime); // Absolute difference

        // Convert milliseconds to hours
        const hoursDifference = timeDifference / (1000 * 60 * 60); // 1000 ms = 1 sec, 60 sec = 1 min, 60 min = 1 hour

        // Check if the difference is greater than 3 hours
        if (hoursDifference > 3) {
          // If the difference is more than 3 hours
          Toast.show({
            type: "error",
            text1: "Time Difference Exceeded",
            text2: "The time difference must not exceed 3 hours.",
          });
          console.log("The time difference is greater than 3 hours.");
          return;  // Prevent further logic if time difference is invalid
        }
      }

      //to check that the permison is not aplies after the time completed
      if (FromTimeDateAPI && ToTimeDateAPI && date) {
        const fromTime = new Date(FromTimeDateAPI);
        const toTime = new Date(ToTimeDateAPI);
        const now = new Date();
      
        // Trim seconds & ms from now so exact minute matches are allowed
        now.setSeconds(0, 0);
      
        // Extract hours and minutes from FromTimeDateAPI
        const hours = fromTime.getHours();
        const minutes = fromTime.getMinutes();
      
        // Create a Date object from `date` and apply time
        const selectedFromDateTime = new Date(date);
        selectedFromDateTime.setHours(hours, minutes, 0, 0);
      
        // Get just the date part (ignore time)
        const selectedDateOnly = new Date(date);
        selectedDateOnly.setHours(0, 0, 0, 0);
      
        const todayDateOnly = new Date();
        todayDateOnly.setHours(0, 0, 0, 0);
      
        // ❌ Don't allow any date before today (e.g., yesterday)
        if (selectedDateOnly < todayDateOnly) {
          Toast.show({
            type: "error",
            text1: "Invalid Date",
            text2: "Date cannot be before today",
          });
          console.log("Selected date is before today.");
          return;
        }
      
        // If date is today, ensure time is not in the past (allow current time)
        const isToday = selectedDateOnly.getTime() === todayDateOnly.getTime();
      
        if (isToday && selectedFromDateTime < now) {
          Toast.show({
            type: "error",
            text1: "Invalid Time",
            text2: "Time cannot be in the past for today",
          });
          console.log("From time is in the past of today.");
          return;
        }
      
        // ❌ Don't allow FromTime > ToTime
        if (fromTime > toTime) {
          Toast.show({
            type: "error",
            text1: "Invalid Time Range",
            text2: "From time cannot be later than To time",
          });
          console.log("From time is greater than To time.");
          return;
        }
      }
      
      




      //FORM validations ends---------

      setLoad(true)
      alteredData.createdDate = getCurrDateTime();
      alteredData.modifiedDate = getCurrDateTime();
      alteredData.fromDate = mergeDateTimeforDatePicker(date, FromTimeDateAPI);
      alteredData.toDate = mergeDateTimeforDatePicker(date, ToTimeDateAPI);

      console.log("Data To API", alteredData)
      const response = await postToAPI('/RequestPermission', alteredData)
      // console.log("response", response)
      // console.log("MESSAGE CODE ", response.messageCode) // SUCC001
      if (response.messageCode == "SUCC001") {
        Toast.show({
          type: "success",
          text1: "Success",
          text2: "Permission Applied Successfully",
        });
        fetchData();
        //making it to inital value starts
        setData(
          {
            "uid": 0,
            "employee_UID": user.login.employee_UID,
            "roll_UID": user.login.app_RollUID,
            "fromDate": "",
            "toDate": "",
            "remark": "",
            "status": 1,
            "createdDate": "",
            "modifiedBy": 0,
            "modifiedDate": "",
            "leaveFlag": 0,
            "timeFlag": 0,
            "requestType": 1
          }
        )
        setDate(new Date())
        setFromTimeDateAPI(DateTimePickerToApiFormat(new Date()))
        setToTimeDateAPI(DateTimePickerToApiFormat(new Date()))
        setFromTime(new Date())
        setToTime(new Date())
        setError(false)
        //making it to inital value ends
      }
      else {
        Toast.show({
          type: "error",
          text1: "Failed",
          text2: "Some error occured, Try again",
        });
      }

      setShowAdd(false)
    } catch (e) {
      console.log("Error While Api Call", e)
    }
    finally {
      setLoad(false)
    }
  }

  const onBackClicked = () => {
    setShowAdd(false)
  }

  return (
    <View style={styles.container}>
      <Loader visible={Load} />
      {
        !showAdd && MainData.length == 0 &&
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
          <MaterialIcons name="inbox" size={Math.min(width, height) * 0.4} color="#ccc" />
          <Text style={{ marginTop: 20, fontSize: 18, color: '#888' }}>There is no data</Text>
        </View>
      }
      {!showAdd &&
        <FlatList
          data={MainData}
          keyExtractor={(item) => item.uid}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <View style={styles.row}>
                <Text style={styles.label}>Date:</Text>
                <Text style={styles.value}>{formatTOddmmyy(item.fromDate)}</Text>
              </View>

              <View style={styles.row}>
                <Text style={styles.label}>From Time:</Text>
                <Text style={styles.value}>{formatDateTimeFromApiToUITimeOnly(item.fromDate)}</Text>
              </View>

              <View style={styles.row}>
                <Text style={styles.label}>To Time:</Text>
                <Text style={styles.value}>{formatDateTimeFromApiToUITimeOnly(item.toDate)}</Text>
              </View>

              <View style={styles.row}>
                <Text style={styles.label}>Reason:</Text>
                <Text style={styles.value}>{item.remark}</Text>
              </View>

              <View style={styles.row}>
                <Text style={styles.label}>Status:</Text>
                <Text style={[styles.status, { color: StatusColor[item.status] }]}>
                  {item.status === 2 && "Approved" ||
                    item.status === 4 && "Cancelled" ||
                    item.status === 3 && "Rejected" ||
                    item.status === 1 && "Pending"}
                </Text>
              </View>

              {/* Cancel Button */}
              {item.status === 1 && <TouchableOpacity style={styles.cancelButton} onPress={() => handleCancel(item)}>
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>}
            </View>
          )}
        />}

      {showAdd ? (
        <>
          {/* Date Picker starts */}
          <TouchableOpacity style={styles.inputContainer} onPress={() => setShowDatePicker(true)}>
            <MaterialIcons name="calendar-today" size={24} color="#007bff" />
            <Text style={styles.inputText}>Date : </Text>
            <Text style={styles.inputText}>{date.toLocaleDateString()}</Text>
          </TouchableOpacity>

          {showDatePicker && (
            <DateTimePicker
              value={date}
              mode="date"
              display="default"
              onChange={(event, selectedDate) => {
                // console.log("EVENT CHANGED ", selectedDate)
                setShowDatePicker(false);
                // console.log("SELECTED DATE", selectedDate)
                if (selectedDate) setDate(selectedDate);
              }}
            />
          )}
          {/* Date Picker ends */}

          {/* Time Pickers From Starts */}
          <View style={styles.timeContainer}>
            <TouchableOpacity style={styles.timeBox} onPress={() => setShowFromTimePicker(true)}>
              <MaterialIcons name="access-time" size={24} color="#007bff" />
              <Text style={styles.inputText}>From : </Text>
              <Text style={styles.inputTime}>{fromTime ? formatDateTimeFromApiToUITimeOnly(fromTime) : "From Time"}</Text>
            </TouchableOpacity>

            {showFromTimePicker && (
              <DateTimePicker
                value={fromTime || new Date()}
                mode="time"
                display="default"
                onChange={(event, selectedTime) => {
                  setShowFromTimePicker(false);
                  setFromTime(selectedTime || fromTime);
                  // console.log("dfghjk", DateTimePickerToApiFormat(selectedTime))
                  setFromTimeDateAPI(DateTimePickerToApiFormat(selectedTime)); // Logs the time in a readable format
                }}
              />
            )}
            {/* Time Pickers From ends */}

            {/* Time Pickers To Starts */}
            <TouchableOpacity style={styles.timeBox} onPress={() => setShowToTimePicker(true)}>
              <MaterialIcons name="access-time" size={24} color="#007bff" />
              <Text style={styles.inputText}>To : </Text>
              <Text style={styles.inputTime}>{toTime ? formatDateTimeFromApiToUITimeOnly(toTime) : "To Time"}</Text>
            </TouchableOpacity>
            {showToTimePicker && (
              <DateTimePicker
                value={toTime || new Date()}
                mode="time"
                display="default"
                onChange={(event, selectedTime) => {
                  setShowToTimePicker(false);
                  setToTime(selectedTime || toTime);
                  setToTimeDateAPI(DateTimePickerToApiFormat(selectedTime)); // Logs the time in a readable format
                }}
              />
            )}
          </View>
          {/* Time Pickers To Ends */}

          <View style={styles.inputContainer}>
            <MaterialIcons name="info" size={24} color="#007bff" />
            <TextInput
              style={styles.input}
              placeholder="Reason"
              value={Data.remark}
              onChangeText={(e) => {
                updateField("remark", e)
              }}
            />
          </View>
          {Error && (Data.remark == '' || Data.remark == 0) && <Text style={styles.errorText}>Enter this field</Text>}

          {/* Submit & Hide Button */}
          <TouchableOpacity style={styles.submitButton} onPress={onBackClicked}>
            <Text style={styles.submitText}>Cancel</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.backButton} onPress={onSubmit}>
            <Text style={styles.backText}>Submit</Text>
          </TouchableOpacity>
        </>
      ) : (
        <TouchableOpacity onPress={() => setShowAdd(true)} style={styles.floatingButton}>
          <MaterialIcons name="add" size={30} color="white" />
        </TouchableOpacity>
      )}
    </View>
  );
};

export default PermissionRequestForm;

const styles = StyleSheet.create({
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1, // ✅ Added border for consistency
    borderColor: "grey", // ✅ Dull Red Border
  },
  inputText: {
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Text
  },
  inputTime: {
  fontSize: 16,
  color: "black",
  flexShrink: 1, // ✅ Prevent text overflow
},
  timeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  timeBox: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 8,
    flex: 1,
    justifyContent: "flex-start",
    marginRight: 5,
    borderWidth: 1, // ✅ Added border
    borderColor: "black", // ✅ Dull Red Border
  },
  input: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: "black", // ✅ Dull Red Input Text
  },
  submitButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
  },
  showFormButton: {
    backgroundColor: "#D32F2F", // ✅ Dull Red Show Form Button
    padding: 12,
    alignItems: "center",
    borderRadius: 5,
    marginBottom: 10,
  },
  submitText: {
    color: "#D32F2F",
    fontWeight: "bold",
  },
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: "#f5f5f5",
  },
  card: {
    backgroundColor: "#FFF",
    padding: 20,
    borderRadius: 10,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
    padding: 5
  },
  label: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
    color: "black",
  },
  value: {
    fontSize: 18, // Increased font size
    color: "#333",
  },
  status: {
    fontWeight: "bold",
    fontSize: 18, // Increased font size
  },
  floatingButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    width: 70, // Increased size
    height: 70,
    borderRadius: 35,
    backgroundColor: "#D32F2F",
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  cancelButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#D32F2F",  // ✅ Outline color
  },
  buttonText: {
    color: "#D32F2F",  // ✅ Same color as border
    fontSize: 18,
    fontWeight: "bold",
  },
  errorText: {
    color: "red",
    fontSize: 12,
    marginTop: 5,
  },
  backText: {
    color: "#007bff",
    fontWeight: "bold",
  },
  backButton: {
    marginTop: 15,
    backgroundColor: "transparent",  // ✅ Transparent background
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    borderWidth: 2,  // ✅ Adds border
    borderColor: "#007bff",  // ✅ Outline color
  },
});
