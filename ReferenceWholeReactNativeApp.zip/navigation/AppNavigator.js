import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import BottomTabNavigator from './BottomTabNavigator';
import Login from '../screen/login/Login';
import Attendance from '../screen/Dashboard/attendance';
import MissedPunchScreen from '../screen/attendance/MissedPunchScreen';
import HomeScreen from '../screen/home/Home';
import Profile from '../screen/Profile/Profile'
import Reports from '../screen/admin/attendanceReport/reports';
import LoginPin from '../screen/login/loginPin';
import AttendanceList from '../screen/attendance/AttendanceList';



const Stack = createStackNavigator();

const AppNav = () => {

  return (
    <Stack.Navigator initialRouteName='LoginPin'>

    <Stack.Screen
            name="LoginPin"
            component={LoginPin}
            options={{ headerShown: false }}
          />

      <Stack.Screen
        name="Admin"
        component={HomeScreen}
      />

      <Stack.Screen
        name="Login"
        component={Login}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="Attendance"
        component={Attendance}
        options={{ title: 'Recent Attendance' }}
      />

      <Stack.Screen
        name="Profile"
        component={Profile}
        options={{ title: 'Profile' }}
      />
      
      <Stack.Screen
        name="Reports"
        component={Reports}
        options={{ title: 'Reports' }}
      />

      <Stack.Screen
        name="MissedPunchScreen"
        component={MissedPunchScreen}
        options={{ title: 'Missed Punch In & Out' }}
      />

    <Stack.Screen
        name="AttendanceList"
        component={AttendanceList}
        options={{ title: 'Attendance List' }}
      />



    </Stack.Navigator>

  );
};

export default AppNav;
