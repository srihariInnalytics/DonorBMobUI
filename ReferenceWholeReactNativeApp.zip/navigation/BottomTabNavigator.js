import * as React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StyleSheet } from 'react-native';
import { colors } from '../component/config/config';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Attendance from '../screen/attendance/Attendance';
import HomeScreen from '../screen/home/Home';
import Servicecallbooking from '../screen/ServiceCallbooking/Servicecallbooking';
import LeaveRequest from '../screen/leaverequest/Leaverequest';
import Permissionrequest from '../screen/Permission request/Permissionrequest';
import Dashboard from '../screen/Dashboard/dashboard';
import AttendanceReport from '../screen/Attendance Report/Attendancereport';
import Profile from '../screen/Profile/Profile';


const Tab = createBottomTabNavigator();

function BottomTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color }) => {
          let iconName;
          switch (route.name) {
            case 'Home':
              iconName = 'home-outline';
              break;
            case 'Attendance':
              iconName = 'calendar-check-outline';
              break;
            case 'Service Call':
              iconName = 'phone-settings';
              break;
            case 'Leave Request':
              iconName = 'file-document-edit-outline';
              break;

              case 'Permission Request':
                iconName = 'file-document-edit-outline';
                break;

                case 'Attendance Report':
                iconName = 'file-document-edit-outline';
                break;

            default:
              iconName = 'circle';
              break;
          }
          return <MaterialCommunityIcons name={iconName} size={24} color={color} />;
        },
        tabBarActiveTintColor: colors.icon,
        tabBarInactiveTintColor: colors.data,
        tabBarStyle: {
          backgroundColor: 'black',
          paddingBottom: 20,
          paddingTop: 5,
          height: 65,
          borderTopWidth: 0,
          elevation: 5,
        },
        tabBarLabelStyle: { fontSize: 10 },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Dashboard" component={Dashboard} />
      <Tab.Screen name="Attendance" component={Attendance} />
      <Tab.Screen name="Service Call" component={Servicecallbooking} />
      <Tab.Screen name="Leave Request" component={LeaveRequest} />
      <Tab.Screen name="Permission Request" component={Permissionrequest} />
      <Tab.Screen name="Attendance Report" component={AttendanceReport} />
      <Tab.Screen name="Profile" component={Profile} />



    </Tab.Navigator>
  );
}

export default BottomTabNavigator;
