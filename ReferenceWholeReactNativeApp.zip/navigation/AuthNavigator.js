import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import LoginScreen from "../screen/login/Login";
import OtpScreen from "../screen/login/OtpScreen";
import NewPin from "../screen/login/NewPin";

const Stack = createStackNavigator();

const AuthNavigator = () => (
  <Stack.Navigator initialRouteName="Login">
    <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
    <Stack.Screen name="OtpScreen" component={OtpScreen} options={{ headerShown: false }} />
    <Stack.Screen name="NewPin" component={NewPin} options={{ headerShown: false }} />
  </Stack.Navigator>
);

export default AuthNavigator;
