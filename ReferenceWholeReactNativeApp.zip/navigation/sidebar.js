import { createDrawerNavigator } from "@react-navigation/drawer";
import HomeScreen from "../screen/home/Home";
import Servicecallbooking from '../screen/ServiceCallbooking/Servicecallbooking';
import Attendance from '../screen/attendance/Attendance';
import LeaveRequest from '../screen/leaverequest/Leaverequest';

// import FeedScreen from "../screens/FeedScreen";
// import ProfileScreen from "../screens/ProfileScreen";
// import SettingsScreen from "../screens/SettingsScreen";

const Drawer = createDrawerNavigator();

export default function AppNavigator() {
  return (
    <Drawer.Navigator>
      <Drawer.Screen name="Home" component={HomeScreen} />
      <Drawer.Screen name="Attendance" component={Attendance} />
      {/* <Drawer.Screen name="Profile" component={ProfileScreen} /> */}
      {/* <Drawer.Screen name="Settings" component={SettingsScreen} /> */}
    </Drawer.Navigator>
  );
}
